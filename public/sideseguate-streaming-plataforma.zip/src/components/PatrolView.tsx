import React, { useState, useEffect } from 'react';
import { Camera } from '../lib/types';
import { LiveCameraPlayer } from './LiveCameraPlayer';
import { 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  RotateCw, 
  Clock, 
  ShieldCheck, 
  Eye, 
  Link2 
} from 'lucide-react';

interface PatrolViewProps {
  cameras: Camera[];
  onGenerateLink: (camera: Camera) => void;
}

export const PatrolView: React.FC<PatrolViewProps> = ({ cameras, onGenerateLink }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [intervalSeconds, setIntervalSeconds] = useState(8);
  const [timeLeft, setTimeLeft] = useState(intervalSeconds);

  useEffect(() => {
    if (!isPlaying || cameras.length === 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setCurrentIndex((idx) => (idx + 1) % cameras.length);
          return intervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPlaying, intervalSeconds, cameras.length]);

  const handleNext = () => {
    setCurrentIndex((idx) => (idx + 1) % cameras.length);
    setTimeLeft(intervalSeconds);
  };

  const handlePrev = () => {
    setCurrentIndex((idx) => (idx - 1 + cameras.length) % cameras.length);
    setTimeLeft(intervalSeconds);
  };

  const activeCamera = cameras[currentIndex] || cameras[0];
  const progressPercent = ((intervalSeconds - timeLeft) / intervalSeconds) * 100;

  if (cameras.length === 0) {
    return (
      <div className="bg-neutral-900/60 border border-neutral-850 rounded-xl p-12 text-center text-xs text-neutral-400">
        No hay cámaras registradas para patrullaje.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Control Banner */}
      <div className="bg-neutral-900/60 border border-neutral-850 p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse"></span>
            <h3 className="text-sm font-bold text-white tracking-tight">
              Modo Patrullaje Continuo (Tour Automático)
            </h3>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Alterna automáticamente entre todos los canales de video cada {intervalSeconds} segundos. Ideal para salas de seguridad y monitores secundarios.
          </p>
        </div>

        {/* Carousel Controls */}
        <div className="flex flex-wrap items-center gap-3 bg-neutral-950 p-1.5 rounded-xl border border-neutral-850 text-xs">
          <button
            aria-label="Cámara anterior"
            onClick={handlePrev}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-850 transition"
            title="Cámara Anterior"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            aria-label={isPlaying ? 'Pausar patrullaje' : 'Reanudar patrullaje'}
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-3 py-1.5 bg-neutral-850 hover:bg-neutral-750 text-white font-medium rounded-lg flex items-center gap-1.5 transition"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPlaying ? 'Pausar' : 'Iniciar'}</span>
          </button>

          <button
            aria-label="Siguiente cámara"
            onClick={handleNext}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-850 transition"
            title="Siguiente Cámara"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <div className="h-5 w-px bg-neutral-800"></div>

          {/* Interval Selector */}
          <div className="flex items-center gap-1.5 text-neutral-400 text-xs">
            <Clock className="w-3.5 h-3.5 text-neutral-500" />
            <select
              value={intervalSeconds}
              onChange={(e) => {
                const val = Number(e.target.value);
                setIntervalSeconds(val);
                setTimeLeft(val);
              }}
              className="bg-transparent border-none text-white text-xs focus:outline-none cursor-pointer"
            >
              <option value={5}>5 seg</option>
              <option value={8}>8 seg</option>
              <option value={15}>15 seg</option>
              <option value={30}>30 seg</option>
            </select>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-neutral-900 h-1.5 rounded-full overflow-hidden border border-neutral-850">
        <div
          className="bg-sky-500 h-full transition-all duration-1000 ease-linear rounded-full"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Main Focus Camera Player */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-3 flex flex-col gap-3">
          <LiveCameraPlayer
            camera={activeCamera}
            allowPtz={true}
            allowAudio={true}
            allowSnapshot={true}
            showWatermark={false}
          />

          <div className="bg-neutral-900/60 border border-neutral-850 p-3.5 rounded-xl flex items-center justify-between text-xs">
            <div>
              <div className="font-semibold text-white text-sm">{activeCamera.name}</div>
              <div className="text-neutral-400 text-xs">{activeCamera.locationDesc}</div>
            </div>

            <button
              onClick={() => onGenerateLink(activeCamera)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold flex items-center gap-1.5 transition text-xs shadow-sm"
            >
              <Link2 className="w-3.5 h-3.5" />
              <span>Generar Enlace</span>
            </button>
          </div>
        </div>

        {/* Camera Carousel Selector Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <div className="text-[11px] font-semibold text-neutral-500 uppercase tracking-wider font-mono px-1">
            Cola de Patrullaje ({cameras.length})
          </div>

          <div className="space-y-1.5">
            {cameras.map((cam, idx) => {
              const isCurrent = idx === currentIndex;
              return (
                <div
                  key={cam.id}
                  onClick={() => {
                    setCurrentIndex(idx);
                    setTimeLeft(intervalSeconds);
                  }}
                  className={`p-2.5 rounded-xl border cursor-pointer transition flex items-center justify-between gap-2 ${
                    isCurrent
                      ? 'bg-neutral-850 border-neutral-700 text-white shadow-sm'
                      : 'bg-neutral-950/60 border-neutral-850 text-neutral-400 hover:bg-neutral-900/60 hover:text-neutral-200'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className={`w-1.5 h-1.5 rounded-full ${cam.status === 'online' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                    <span className="font-medium text-xs truncate max-w-[150px]">
                      {cam.name}
                    </span>
                  </div>
                  {isCurrent && (
                    <span className="text-[10px] font-mono text-sky-400 font-bold">
                      {timeLeft}s
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

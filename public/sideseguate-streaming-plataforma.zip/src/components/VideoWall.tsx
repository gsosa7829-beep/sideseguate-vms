import React, { useState } from 'react';
import { Camera } from '../lib/types';
import { LiveCameraPlayer } from './LiveCameraPlayer';
import { 
  LayoutGrid, 
  Square, 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Plus, 
  Eye, 
  Link2,
  Grid3X3,
  Columns
} from 'lucide-react';

interface VideoWallProps {
  cameras: Camera[];
  onSelectCamera: (id: string) => void;
  onOpenNewCamera: () => void;
  onGenerateLink: (camera: Camera) => void;
}

export const VideoWall: React.FC<VideoWallProps> = ({
  cameras,
  onSelectCamera,
  onOpenNewCamera,
  onGenerateLink,
}) => {
  const [gridSize, setGridSize] = useState<'1' | '2' | '3'>('2');
  const [filterType, setFilterType] = useState<string>('all');

  const filteredCameras = cameras.filter((cam) => {
    if (filterType === 'all') return true;
    return cam.deviceType === filterType;
  });

  return (
    <div className="space-y-4">
      {/* Wall Header & Controls */}
      <div className="bg-neutral-900/60 border border-neutral-850 p-3 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-bold text-white tracking-wide">
              Muro de Vigilancia en Vivo
            </span>
          </div>
          <span className="text-neutral-600 text-xs">·</span>
          <span className="text-xs text-neutral-400 font-mono">
            {cameras.filter((c) => c.status === 'online').length} Canales Transmitiendo
          </span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          {/* Hardware filter */}
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 text-neutral-300 text-xs rounded-lg px-2.5 py-1 focus:outline-none"
          >
            <option value="all">Todas las Cámaras ({cameras.length})</option>
            <option value="hikvision_dvr">Hikvision DVRs</option>
            <option value="hikvision_ip">Hikvision IP</option>
            <option value="v380_4g">T-DAY 4G V380</option>
          </select>

          {/* Grid Layout Switcher: 1x1, 2x2, 3x3 */}
          <div className="flex items-center bg-neutral-950 p-0.5 rounded-lg border border-neutral-800 text-xs">
            <button
              onClick={() => setGridSize('1')}
              className={`p-1.5 rounded-md transition ${
                gridSize === '1' ? 'bg-neutral-850 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
              }`}
              title="Vista 1x1 (Grande)"
            >
              <Square className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setGridSize('2')}
              className={`p-1.5 rounded-md transition ${
                gridSize === '2' ? 'bg-neutral-850 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
              }`}
              title="Matriz 2x2 (4 Canales)"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setGridSize('3')}
              className={`p-1.5 rounded-md transition ${
                gridSize === '3' ? 'bg-neutral-850 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
              }`}
              title="Matriz 3x3 (9 Canales)"
            >
              <Grid3X3 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Grid Canvas */}
      {filteredCameras.length === 0 ? (
        <div className="bg-neutral-900/60 border border-neutral-850 rounded-xl p-12 text-center">
          <p className="text-xs text-neutral-400 mb-3">No hay cámaras en esta categoría.</p>
          <button
            onClick={onOpenNewCamera}
            className="px-3.5 py-1.5 bg-white text-neutral-950 font-semibold rounded-lg text-xs inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Añadir Cámara</span>
          </button>
        </div>
      ) : (
        <div
          className={`grid gap-3.5 ${
            gridSize === '1'
              ? 'grid-cols-1'
              : gridSize === '2'
              ? 'grid-cols-1 md:grid-cols-2'
              : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
          }`}
        >
          {filteredCameras.map((cam) => (
            <div
              key={cam.id}
              className="bg-neutral-900/80 border border-neutral-850 hover:border-neutral-750 transition rounded-xl overflow-hidden shadow-sm flex flex-col group"
            >
              {/* Header Bar */}
              <div className="px-3 py-2 bg-neutral-950 border-b border-neutral-850 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <span className={`w-1.5 h-1.5 rounded-full ${cam.status === 'online' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                  <span className="font-semibold text-white truncate max-w-[170px] sm:max-w-xs">
                    {cam.name}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-neutral-400 text-[11px] font-mono">
                  <span>CH{cam.channel}</span>
                  <span className="text-neutral-600">·</span>
                  <span>{cam.resolution.split(' ')[0]}</span>
                </div>
              </div>

              {/* Player */}
              <div className="flex-1 bg-black">
                <LiveCameraPlayer
                  camera={cam}
                  allowPtz={true}
                  allowAudio={true}
                  allowSnapshot={true}
                  showWatermark={false}
                  isCompact={gridSize !== '1'}
                />
              </div>

              {/* Footer Controls Strip */}
              <div className="px-3 py-2 bg-neutral-950/90 border-t border-neutral-850 flex items-center justify-between text-xs">
                <div className="text-[11px] text-neutral-400 truncate max-w-[180px]">
                  {cam.locationDesc}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => onSelectCamera(cam.id)}
                    className="p-1 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition"
                    title="Inspeccionar en Detalle"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onGenerateLink(cam)}
                    className="p-1 text-neutral-400 hover:text-blue-400 rounded hover:bg-neutral-800 transition"
                    title="Generar Enlace para Cliente"
                  >
                    <Link2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

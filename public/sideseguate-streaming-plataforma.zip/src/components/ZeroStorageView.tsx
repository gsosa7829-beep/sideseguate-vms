import React, { useState } from 'react';
import { 
  CloudOff, 
  Server, 
  DollarSign, 
  HardDrive, 
  CheckCircle2, 
  ArrowRight, 
  ShieldCheck, 
  Clock, 
  Radio, 
  Laptop,
  Check
} from 'lucide-react';

export const ZeroStorageView: React.FC = () => {
  const [numCameras, setNumCameras] = useState(4);
  const [viewHoursPerDay, setViewHoursPerDay] = useState(2);

  // Traditional cloud recording cost: ~$15/cam/month + storage fees
  const traditionalCostMonthly = numCameras * 18;
  const sideseguateVPSCost = 10; // $10/mo for a Windows VPS or $0 for local PC

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-neutral-900/60 border border-neutral-850 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CloudOff className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Arquitectura Cero Nube: Streaming en Vivo Bajo Demanda
            </h3>
          </div>
          <p className="text-xs text-neutral-400 max-w-2xl leading-relaxed">
            Configuración técnica que garantiza 0 MB de almacenamiento de video en disco duro y $0 costos de almacenamiento en servidores externos.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/80 font-bold">
            0 GB EN DISCO
          </span>
        </div>
      </div>

      {/* 3 Step On-Demand Lifecycle */}
      <div className="bg-neutral-900/70 border border-neutral-850 rounded-xl p-5 shadow-sm space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
          ¿Cómo funciona el Proxy en Vivo sin guardar video? (Ciclo de Vida)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Step 1 */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-neutral-850 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-mono font-bold text-neutral-500 mb-1">FASE 1 · REPOSO</div>
              <h5 className="font-semibold text-white mb-2">Ningún cliente conectado</h5>
              <p className="text-neutral-400 leading-relaxed text-[11px]">
                Gracias a la directiva <code className="text-sky-300 font-mono">sourceOnDemand: yes</code> en MediaMTX, el servidor no solicita el video a las cámaras Hikvision.
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-850 font-mono text-[10px] text-emerald-400">
              Consumo: 0 kbps · Disco: 0 MB
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-neutral-850 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-mono font-bold text-blue-400 mb-1">FASE 2 · ENLACE ABIERTO</div>
              <h5 className="font-semibold text-white mb-2">Cliente abre enlace web</h5>
              <p className="text-neutral-400 leading-relaxed text-[11px]">
                En ese milisegundo MediaMTX abre la sesión RTSP (:554), convierte la señal a formato web (HLS) en la memoria RAM y se la entrega al navegador del cliente.
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-850 font-mono text-[10px] text-blue-400">
              Video en vivo directo (RAM)
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-neutral-850 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-mono font-bold text-emerald-400 mb-1">FASE 3 · CIERRE</div>
              <h5 className="font-semibold text-white mb-2">Cliente cierra la pestaña</h5>
              <p className="text-neutral-400 leading-relaxed text-[11px]">
                A los 10 segundos de inactividad, MediaMTX desconecta el flujo de la cámara automáticamente. No queda ningún archivo residual guardado.
              </p>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-850 font-mono text-[10px] text-emerald-400">
              Cierre automático · Limpieza total
            </div>
          </div>
        </div>
      </div>

      {/* Cost & Infrastructure Comparison Calculator */}
      <div className="bg-neutral-900/70 border border-neutral-850 rounded-xl p-5 shadow-sm space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
          Comparativa de Costos Mensuales: Grabación en Nube vs. Plataforma SIDESEGUATE
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Traditional Cloud Storage */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-red-900/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Nube Tradicional (AWS / Cloud VMS)</span>
              <span className="text-red-400 font-mono font-bold">~${traditionalCostMonthly}/mes</span>
            </div>
            <ul className="space-y-2 text-neutral-400 text-[11px]">
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">✕</span>
                <span>Cobra mensualidad por cada cámara conectada ($15 a $20/cámara).</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">✕</span>
                <span>Guarda semanas de video que nadie revisa y factura por gigabytes almacenados.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">✕</span>
                <span>Obliga a registrar tarjetas de crédito con cobros recurrentes impredecibles.</span>
              </li>
            </ul>
          </div>

          {/* SIDESEGUATE Windows On-Demand */}
          <div className="bg-neutral-950/80 p-4 rounded-xl border border-emerald-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white">Plataforma SIDESEGUATE (Windows Gateway)</span>
              <span className="text-emerald-400 font-mono font-bold">$0 a $10/mes</span>
            </div>
            <ul className="space-y-2 text-neutral-300 text-[11px]">
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>$0 en la nube:</strong> Cero almacenamiento, cero costos por gigabyte.</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Opción A:</strong> Servidor VPS Windows fijo de $8 a $10/mes (Kamatera/Contabo).</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span><strong>Opción B:</strong> Tu propia PC/Laptop en la oficina con costo $0.00.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

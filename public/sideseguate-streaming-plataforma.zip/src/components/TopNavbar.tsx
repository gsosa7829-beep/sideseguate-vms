import React, { useEffect, useState } from 'react';
import { NavigationTab } from '../lib/types';
import {
  Plus,
  Search,
  Smartphone,
  Link2,
  Cloud,
  CheckCircle2,
  X,
  LogIn,
  LogOut,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import {
  GOOGLE_CLOUD_PROJECT_ID,
  subscribeToAuth,
  signInWithGoogle,
  signOutFromGoogle,
  syncVmsWorkspaceToCloud
} from '../lib/firebase';
import type { User } from 'firebase/auth';

interface TopNavbarProps {
  currentTab: NavigationTab;
  onOpenNewLink: () => void;
  onOpenNewCamera: () => void;
  onOpenMobilePreview: () => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  camerasOnline: number;
  totalCameras: number;
  totalLinks: number;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  currentTab,
  onOpenNewLink,
  onOpenNewCamera,
  onOpenMobilePreview,
  searchTerm,
  onSearchChange,
  camerasOnline,
  totalCameras,
  totalLinks,
}) => {
  const [cloudUser, setCloudUser] = useState<User | null>(null);
  const [showCloudModal, setShowCloudModal] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced' | 'error'>('idle');
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToAuth((u) => {
      setCloudUser(u);
    });
    return () => unsub();
  }, []);

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    try {
      await signInWithGoogle();
      setSyncStatus('syncing');
      await syncVmsWorkspaceToCloud({
        gatewayHost: '192.168.1.41:8889',
        projectsCount: 2,
        camerasCount: totalCameras,
        shareLinksCount: totalLinks,
      });
      setSyncStatus('synced');
    } catch (err) {
      setSyncStatus('error');
      setAuthError(err instanceof Error ? err.message : 'No se pudo completar el inicio de sesión');
    }
  };

  const handleManualSync = async () => {
    if (!cloudUser) return;
    setSyncStatus('syncing');
    setAuthError(null);
    try {
      await syncVmsWorkspaceToCloud({
        gatewayHost: '192.168.1.41:8889',
        projectsCount: 2,
        camerasCount: totalCameras,
        shareLinksCount: totalLinks,
      });
      setSyncStatus('synced');
    } catch (err) {
      setSyncStatus('error');
      setAuthError(err instanceof Error ? err.message : 'Error al sincronizar con Firestore');
    }
  };

  const getTabTitle = (tab: NavigationTab) => {
    switch (tab) {
      case 'videowall':
        return { section: 'MONITOREO', title: 'Muro de Video (Matriz Multicámara)' };
      case 'single_camera':
        return { section: 'MONITOREO', title: 'Inspección & Control PTZ' };
      case 'patrol':
        return { section: 'MONITOREO', title: 'Carrusel de Patrullaje Continuo' };
      case 'share_links':
        return { section: 'CLIENTES', title: 'Gestor de Enlaces Web Temporales' };
      case 'clients_projects':
        return { section: 'CLIENTES', title: 'Directorio de Clientes & Proyectos' };
      case 'access_audit':
        return { section: 'CLIENTES', title: 'Auditoría & Registro de Conexiones' };
      case 'devices_catalog':
        return { section: 'EQUIPOS & RED', title: 'Inventario de Cámaras & DVRs' };
      case 'sadp_scanner':
        return { section: 'EQUIPOS & RED', title: 'Escáner SADP Tool (Red Local)' };
      case 'windows_server':
        return { section: 'SERVIDOR WINDOWS', title: 'Gateway MediaMTX para Windows' };
      case 'zero_storage':
        return { section: 'SERVIDOR WINDOWS', title: 'Arquitectura Cero Nube (Bajo Demanda)' };
      case 'mediamtx_config':
        return { section: 'SERVIDOR WINDOWS', title: 'Configurador mediamtx.yml' };
      default:
        return { section: 'VMS', title: 'Consola de Operaciones' };
    }
  };

  const { section, title } = getTabTitle(currentTab);

  return (
    <>
      <header className="h-14 bg-neutral-900/80 border-b border-neutral-850 px-4 flex items-center justify-between gap-4 sticky top-0 z-20 backdrop-blur-md">
        {/* Breadcrumbs & Title */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex sm:hidden items-center gap-2">
            <img
              src="/logo-sideseguate.jpg"
              alt="SIDESEGUATE"
              className="w-7 h-7 rounded-lg object-cover bg-white shrink-0 shadow-sm"
            />
            <span className="font-bold text-xs text-white">SIDESEGUATE</span>
          </div>
          <div className="hidden sm:flex flex-col">
            <span className="text-[10px] font-mono font-semibold text-neutral-500 uppercase tracking-wider">
              {section}
            </span>
            <h2 className="text-xs font-bold text-white tracking-tight truncate max-w-xs md:max-w-md">
              {title}
            </h2>
          </div>
        </div>

        {/* Global Quick Search */}
        <div className="hidden md:flex items-center gap-2 flex-1 min-w-[210px] max-w-xs bg-neutral-950/80 px-3 py-1.5 rounded-lg border border-neutral-850 text-xs">
          <Search className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Buscar cámara, cliente o IP..."
            className="bg-transparent border-none text-xs text-white placeholder-neutral-500 focus:outline-none w-full"
          />
        </div>

        {/* Live System KPIs */}
        <div className="hidden xl:flex items-center gap-2.5 text-xs font-mono tabular-nums text-neutral-400 whitespace-nowrap shrink-0">
          <span className="text-emerald-400 font-semibold">{camerasOnline}/{totalCameras} En Vivo</span>
          <span className="text-neutral-700">·</span>
          <span>{totalLinks} Enlaces</span>
          <span className="text-neutral-700">·</span>
          <span className="text-neutral-300">0 MB Video</span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setShowCloudModal(true)}
            className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm whitespace-nowrap"
            title="Estado de Google Cloud Run & Firebase"
          >
            <Cloud className="w-3.5 h-3.5 text-sky-400 shrink-0" />
            <span className="hidden lg:inline">Google Cloud</span>
          </button>

          <button
            onClick={onOpenNewLink}
            className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm whitespace-nowrap"
            title="Generar Enlace Temporal para Cliente"
          >
            <Link2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span className="hidden sm:inline">Nuevo Enlace</span>
          </button>

          <button
            onClick={onOpenNewCamera}
            className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm whitespace-nowrap"
            title="Agregar Cámara o DVR Hikvision"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="hidden sm:inline">Añadir Cámara</span>
          </button>

          <button
            onClick={onOpenMobilePreview}
            className="px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-sm whitespace-nowrap"
            title="Simulador de Vista Móvil para el Cliente"
          >
            <Smartphone className="w-3.5 h-3.5 text-neutral-800" />
            <span>Vista Móvil</span>
          </button>
        </div>
      </header>

      {showCloudModal && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setShowCloudModal(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-lg shadow-2xl text-neutral-100 overflow-hidden"
          >
            <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
              <div className="flex items-center gap-2.5">
                <Cloud className="w-5 h-5 text-sky-400" />
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Infraestructura Google Cloud & Firebase
                  </h3>
                  <p className="text-[11px] text-neutral-400 font-mono">
                    Proyecto vinculado: {GOOGLE_CLOUD_PROJECT_ID}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCloudModal(false)}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* Cloud Hosting Options */}
              <div className="bg-neutral-950 border border-neutral-850 rounded-xl p-4 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">
                    1. Alojar este sitio web en Google Cloud Run / Firebase
                  </span>
                  <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Listo
                  </span>
                </div>
                <p className="text-neutral-400 leading-relaxed">
                  Tu proyecto <code className="text-sky-400 font-mono">{GOOGLE_CLOUD_PROJECT_ID}</code> ya cuenta con <code className="font-mono text-neutral-200">Dockerfile</code> para <strong>Google Cloud Run</strong> y <code className="font-mono text-neutral-200">firebase.json</code> para <strong>Firebase Hosting</strong>.
                </p>
                <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-3 space-y-1.5 text-[11px] text-neutral-300">
                  <div>
                    • <strong>Opción A (1 clic aquí arriba):</strong> Haz clic en el icono del <strong>Cohete (Deploy to Cloud Run)</strong> arriba a la derecha de la barra superior para publicarlo directamente en Google Cloud Run.
                  </div>
                  <div>
                    • <strong>Opción B (Firebase Hosting):</strong> Desde tu PC o Cloud Shell ejecuta <code className="font-mono text-sky-400">firebase deploy --only hosting</code>.
                  </div>
                </div>
                <a
                  href={`https://console.firebase.google.com/project/${GOOGLE_CLOUD_PROJECT_ID}/overview`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-sky-400 hover:text-sky-300 font-medium pt-1"
                >
                  <span>Abrir Consola de Google Cloud / Firebase</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Cloud Auth & Firestore Sync */}
              <div className="bg-neutral-950 border border-neutral-850 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">
                    2. Base de Datos Firestore & Autenticación Google
                  </span>
                  <span className="text-[11px] font-mono text-neutral-400">
                    {cloudUser ? 'Sesión Activa' : 'Sin iniciar sesión'}
                  </span>
                </div>

                {cloudUser ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-2">
                      <div className="min-w-0">
                        <div className="font-medium text-white truncate">
                          {cloudUser.displayName || 'Operador SIDESEGUATE'}
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono truncate">
                          {cloudUser.email}
                        </div>
                      </div>
                      <button
                        onClick={() => signOutFromGoogle()}
                        className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-[11px] flex items-center gap-1"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Salir</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <button
                        onClick={handleManualSync}
                        disabled={syncStatus === 'syncing'}
                        className="flex-1 py-2 px-3 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded-lg flex items-center justify-center gap-1.5 transition"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${syncStatus === 'syncing' ? 'animate-spin' : ''}`} />
                        <span>
                          {syncStatus === 'syncing'
                            ? 'Sincronizando con Google Cloud...'
                            : 'Sincronizar Estado en Firestore'}
                        </span>
                      </button>
                    </div>

                    {syncStatus === 'synced' && (
                      <div className="text-[11px] text-emerald-400 font-mono">
                        ✓ Estado sincronizado en /vms_workspaces/{cloudUser.uid.slice(0, 10)}...
                      </div>
                    )}
                  </div>
                ) : (
                  <button
                    onClick={handleGoogleSignIn}
                    className="w-full py-2.5 px-4 bg-white hover:bg-neutral-100 text-neutral-950 font-semibold rounded-lg flex items-center justify-center gap-2 transition"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Iniciar Sesión con Google para Respaldar en Firestore</span>
                  </button>
                )}

                {authError && (
                  <div className="text-[11px] text-amber-400 bg-amber-950/40 border border-amber-800/50 rounded-lg p-2.5">
                    {authError}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

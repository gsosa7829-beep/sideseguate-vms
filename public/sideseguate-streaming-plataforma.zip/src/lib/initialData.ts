import { Project, Camera, ShareLink, AccessLog } from './types';

export const CLIENT_HIKVISION_HARDWARE = [
  {
    model: 'iDS-7108HQHI-M1/S0',
    name: 'Hikvision AcuSense 8CH (Detectado en SADP Tool)',
    shortSerial: 'L18365299',
    macAddress: 'e0:ba:ad:cd:bc:05',
    lanIp: '192.168.1.41',
    gateway: '192.168.1.1',
    subnet: '255.255.255.0',
    serverPort: 8000,
    httpPort: 80,
    rtspPort: 554,
    totalChannels: 8,
    recommendedStream: '1080p Lite / 4MP AcuSense',
    rtspSyntaxExample: 'rtsp://vi1fdr:Dvr232323@192.168.1.41:554/Streaming/Channels/101'
  },
  {
    model: 'iDS-7204HUHI-M1/S',
    name: 'Hikvision AcuSense DVR (4 Canales)',
    serial: '0420240307CCWRFB2200254WCVU',
    firmware: 'V4.75.013, Build 240919',
    hardwareVer: '0xc0fbe00',
    totalChannels: 4,
    recommendedStream: '1080p / 5MP TurboHD',
    rtspSyntaxExample: 'rtsp://vi1fdr:Dvr232323@IP:554/Streaming/Channels/101'
  },
  {
    model: 'DS-7108HGHI-F1/N',
    name: 'Hikvision TurboHD DVR (8 Canales)',
    serial: 'F30392314',
    mfgDate: '12/2020',
    totalChannels: 8,
    recommendedStream: '720p / 1080p Lite',
    rtspSyntaxExample: 'rtsp://vi1fdr:Dvr232323@IP:554/Streaming/Channels/101'
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-sideseguate-01',
    name: 'Proyecto SIDESEGUATE (LAN 192.168.1.41)',
    clientName: 'Lic. Fernando Morales',
    clientPhone: '+502 5521-8840',
    location: 'Red Local: 192.168.1.1 Gateway / DVR en 192.168.1.41',
    budgetQ: 10500,
    targetWeeks: 4,
    status: 'en_instalacion',
    equipmentNotes: 'DVR Hikvision iDS-7108HQHI-M1/S (IP 192.168.1.41, MAC e0:ba:ad:cd:bc:05, SN L18365299) + iDS-7204HUHI-M1/S. User: vi1fdr, Cód: HELGDM.',
    createdAt: '2026-10-10T14:30:00.000Z'
  },
  {
    id: 'proj-sideseguate-02',
    name: 'Sede Corporativa Zona 10',
    clientName: 'Ing. Rodrigo Castillo',
    clientPhone: '+502 4410-9090',
    location: '12 Calle 4-55 Zona 10, Edificio Reforma Plaza',
    budgetQ: 8500,
    targetWeeks: 3,
    status: 'activo',
    equipmentNotes: 'NVR Hikvision IP 16CH, streaming directo a MediaMTX vía fibra simétrica.',
    createdAt: '2026-10-15T09:00:00.000Z'
  }
];

export const INITIAL_CAMERAS: Camera[] = [
  // DVR 1 (From Client Photo 1): iDS-7204HUHI-M1/S (4 Channels)
  {
    id: 'cam-ids-ch1',
    projectId: 'proj-sideseguate-01',
    name: 'CH1: Entrada Principal (iDS-7204HUHI-M1/S)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.34',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 1,
    streamType: 'main',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.34:554/Streaming/Channels/101',
    status: 'online',
    fps: 25,
    resolution: '1920x1080 (1080p FHD)',
    bitrateKbps: 2048,
    codec: 'H.264',
    locationDesc: 'Acceso y garita vehicular - Canal 1 DVR iDS-7204HUHI-M1/S (SN: 0420240307CCWRFB2200254WCVU)',
    ptzSupported: false,
    nightVision: true,
    notes: 'Modelo: iDS-7204HUHI-M1/S | User: vi1fdr | Pass: Dvr232323 | Código Verificación: HELGDM | SN: 0420240307CCWRFB2200254WCVU'
  },
  {
    id: 'cam-ids-ch2',
    projectId: 'proj-sideseguate-01',
    name: 'CH2: Bodega & Andén (iDS-7204HUHI-M1/S)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.34',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 2,
    streamType: 'main',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.34:554/Streaming/Channels/201',
    status: 'online',
    fps: 25,
    resolution: '1920x1080 (1080p FHD)',
    bitrateKbps: 2048,
    codec: 'H.264',
    locationDesc: 'Interior Bodega Principal - Canal 2 DVR iDS-7204HUHI-M1/S',
    ptzSupported: false,
    nightVision: true,
    notes: 'Canal 2 del DVR cliente iDS-7204HUHI-M1/S | User: vi1fdr | Código Verificación: HELGDM'
  },
  {
    id: 'cam-ids-ch3',
    projectId: 'proj-sideseguate-01',
    name: 'CH3: Parqueo Clientes (iDS-7204HUHI-M1/S Substream)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.34',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 3,
    streamType: 'sub',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.34:554/Streaming/Channels/302',
    status: 'online',
    fps: 20,
    resolution: '1280x720 (720p HD Substream)',
    bitrateKbps: 800,
    codec: 'H.264',
    locationDesc: 'Área perimetral parqueo - Canal 3 Substream (optimizado móvil)',
    ptzSupported: false,
    nightVision: true,
    notes: 'Flujo secundario /302 configurado para reproducción inmediata sin consumo excesivo de datos. User: vi1fdr'
  },
  {
    id: 'cam-ids-ch4',
    projectId: 'proj-sideseguate-01',
    name: 'CH4: Perímetro Exterior (iDS-7204HUHI-M1/S)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.34',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 4,
    streamType: 'main',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.34:554/Streaming/Channels/401',
    status: 'online',
    fps: 25,
    resolution: '1920x1080 (1080p FHD)',
    bitrateKbps: 2048,
    codec: 'H.264',
    locationDesc: 'Malla perimetral trasera - Canal 4 DVR iDS-7204HUHI-M1/S',
    ptzSupported: false,
    nightVision: true,
    notes: 'Canal 4 del DVR cliente | User: vi1fdr | Código Verificación: HELGDM'
  },

  // DVR 2 (From Client Photo 2): DS-7108HGHI-F1/N (8 Channels)
  {
    id: 'cam-ds7108-ch1',
    projectId: 'proj-sideseguate-01',
    name: 'CH1: Recepción & Oficinas (DS-7108HGHI-F1/N)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.36',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 1,
    streamType: 'main',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.36:554/Streaming/Channels/101',
    status: 'online',
    fps: 20,
    resolution: '1280x720 (720p HD)',
    bitrateKbps: 1536,
    codec: 'H.264',
    locationDesc: 'Recepción del edificio - DVR 8CH DS-7108HGHI-F1/N (SN: F30392314)',
    ptzSupported: false,
    nightVision: true,
    notes: 'Modelo: DS-7108HGHI-F1/N | User: vi1fdr | Pass: Dvr232323 | Código: HELGDM | SN: F30392314'
  },
  {
    id: 'cam-ds7108-ch2',
    projectId: 'proj-sideseguate-01',
    name: 'CH2: Pasillo Administrativo (DS-7108HGHI-F1/N)',
    deviceType: 'hikvision_dvr',
    host: '190.86.12.36',
    port: 554,
    onvifPort: 8000,
    username: 'vi1fdr',
    password: 'Dvr232323',
    verificationCode: 'HELGDM',
    channel: 2,
    streamType: 'sub',
    rtspUrl: 'rtsp://vi1fdr:Dvr232323@190.86.12.36:554/Streaming/Channels/202',
    status: 'online',
    fps: 15,
    resolution: '704x480 (4CIF Substream)',
    bitrateKbps: 512,
    codec: 'H.264',
    locationDesc: 'Pasillo interior oficinas - DVR 8CH DS-7108HGHI-F1/N',
    ptzSupported: false,
    nightVision: true,
    notes: 'Canal 2 del DVR DS-7108HGHI-F1/N | User: vi1fdr | Pass: Dvr232323'
  }
];

export const INITIAL_SHARE_LINKS: ShareLink[] = [
  {
    id: 'link-morales-vip',
    projectId: 'proj-sideseguate-01',
    token: 'sdg_live_demo7849',
    title: 'Acceso En Vivo - Cliente Hikvision iDS-7204HUHI-M1/S',
    clientName: 'Lic. Fernando Morales',
    cameraIds: ['cam-ids-ch1', 'cam-ids-ch2', 'cam-ids-ch3', 'cam-ids-ch4'],
    pinCode: '',
    expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days from now
    isActive: true,
    allowPtz: false,
    allowAudio: true,
    allowSnapshot: true,
    showWatermark: true,
    maxConcurrentViewers: 5,
    accessCount: 48,
    lastAccessedAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    createdAt: '2026-10-18T10:00:00.000Z'
  },
  {
    id: 'link-guardia-noche',
    projectId: 'proj-sideseguate-01',
    token: 'sdg_live_guardia91',
    title: 'Enlace Seguridad Nocturna - Garita y Parqueo',
    clientName: 'Supervisor de Turno',
    cameraIds: ['cam-ids-ch1', 'cam-ids-ch3'],
    pinCode: '2026',
    expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days
    isActive: true,
    allowPtz: false,
    allowAudio: false,
    allowSnapshot: true,
    showWatermark: true,
    maxConcurrentViewers: 2,
    accessCount: 18,
    lastAccessedAt: new Date(Date.now() - 1000 * 60 * 60 * 4).toISOString(),
    createdAt: '2026-10-19T18:00:00.000Z'
  },
  {
    id: 'link-ds7108-oficinas',
    projectId: 'proj-sideseguate-01',
    token: 'sdg_live_ds7108_oficinas',
    title: 'Acceso Oficinas - DVR DS-7108HGHI-F1/N (8CH)',
    clientName: 'Gerencia Administrativa',
    cameraIds: ['cam-ds7108-ch1', 'cam-ds7108-ch2'],
    pinCode: '7108',
    expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14).toISOString(), // 14 days
    isActive: true,
    allowPtz: false,
    allowAudio: true,
    allowSnapshot: true,
    showWatermark: true,
    maxConcurrentViewers: 3,
    accessCount: 7,
    lastAccessedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    createdAt: '2026-10-21T14:00:00.000Z'
  }
];

export const INITIAL_ACCESS_LOGS: AccessLog[] = [
  {
    id: 'log-01',
    shareLinkId: 'link-morales-vip',
    clientIp: '190.86.45.112',
    deviceInfo: 'Chrome 128 / Android 14 (Samsung Galaxy S24)',
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    durationSeconds: 340,
    action: 'stream_started'
  },
  {
    id: 'log-02',
    shareLinkId: 'link-morales-vip',
    clientIp: '190.86.45.112',
    deviceInfo: 'Chrome 128 / Android 14',
    timestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
    durationSeconds: 15,
    action: 'snapshot_taken'
  },
  {
    id: 'log-03',
    shareLinkId: 'link-guardia-noche',
    clientIp: '181.174.92.15',
    deviceInfo: 'Safari 18 / iOS 18 (iPhone 15 Pro)',
    timestamp: new Date(Date.now() - 1000 * 60 * 85).toISOString(),
    durationSeconds: 720,
    action: 'stream_started'
  },
  {
    id: 'log-04',
    shareLinkId: 'link-ds7108-oficinas',
    clientIp: '168.234.12.80',
    deviceInfo: 'Edge 129 / Windows 11',
    timestamp: new Date(Date.now() - 1000 * 60 * 210).toISOString(),
    durationSeconds: 450,
    action: 'stream_started'
  },
  {
    id: 'log-05',
    shareLinkId: 'link-guardia-noche',
    clientIp: '181.174.92.15',
    deviceInfo: 'Safari 18 / iOS 18',
    timestamp: new Date(Date.now() - 1000 * 60 * 350).toISOString(),
    durationSeconds: 5,
    action: 'auth_failed'
  }
];

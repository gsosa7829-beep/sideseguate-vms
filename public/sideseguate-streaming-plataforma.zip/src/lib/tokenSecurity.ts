import { ShareLink } from './types';

/**
 * Generates a collision-resistant private access token.
 */
export function generateShareToken(prefix: string = 'sdg'): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let token = `${prefix}_live_`;
  for (let i = 0; i < 16; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
}

export interface VerificationResult {
  valid: boolean;
  reason?: 'expired' | 'inactive' | 'invalid_pin' | 'pin_required' | 'not_found';
  message: string;
}

/**
 * Checks if a share link is valid, active, not expired, and satisfies PIN.
 */
export function verifyShareLink(link: ShareLink | null | undefined, providedPin?: string): VerificationResult {
  if (!link) {
    return {
      valid: false,
      reason: 'not_found',
      message: 'El enlace de videovigilancia no existe o fue eliminado.'
    };
  }

  if (!link.isActive) {
    return {
      valid: false,
      reason: 'inactive',
      message: 'Este enlace ha sido desactivado temporalmente por el administrador de SIDESEGUATE.'
    };
  }

  if (link.expiresAt) {
    const expiryTime = new Date(link.expiresAt).getTime();
    const now = Date.now();
    if (now >= expiryTime) {
      return {
        valid: false,
        reason: 'expired',
        message: 'El enlace de acceso ha expirado. Comuníquese con SIDESEGUATE para renovarlo.'
      };
    }
  }

  if (link.pinCode) {
    if (!providedPin) {
      return {
        valid: false,
        reason: 'pin_required',
        message: 'Este canal privado requiere un código PIN de seguridad.'
      };
    }
    if (providedPin.trim() !== link.pinCode.trim()) {
      return {
        valid: false,
        reason: 'invalid_pin',
        message: 'El código PIN ingresado es incorrecto.'
      };
    }
  }

  return {
    valid: true,
    message: 'Enlace válido y autorizado.'
  };
}

/**
 * Formats expiration dates to human-friendly Spanish text.
 */
export function formatExpirationText(expiresAt: string | null): string {
  if (!expiresAt) {
    return 'Sin caducidad (Permanente)';
  }

  const now = Date.now();
  const expiry = new Date(expiresAt).getTime();
  const diffMs = expiry - now;

  if (diffMs <= 0) {
    return 'Expirado';
  }

  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHours / 24);

  if (diffDays >= 1) {
    const remHours = diffHours % 24;
    return `Expira en ${diffDays} día${diffDays > 1 ? 's' : ''}${remHours > 0 ? ` y ${remHours}h` : ''}`;
  } else if (diffHours >= 1) {
    const remMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `Expira en ${diffHours}h ${remMinutes}m`;
  } else {
    const remMinutes = Math.max(1, Math.floor(diffMs / (1000 * 60)));
    return `Expira en ${remMinutes} minuto${remMinutes > 1 ? 's' : ''}`;
  }
}

/**
 * Utility functions for RTSP URLs, ONVIF discovery, and device syntax.
 */

export interface HikvisionParams {
  host: string;
  port?: number;
  username: string;
  password?: string;
  channel: number;
  streamType: 'main' | 'sub';
}

/**
 * Builds the standard Hikvision RTSP URL.
 * Format: rtsp://[user]:[pass]@[host]:[port]/Streaming/Channels/[channel]0[streamType: 1=main, 2=sub]
 * Example: rtsp://admin:12345@190.86.20.10:554/Streaming/Channels/101
 */
export function buildHikvisionRtspUrl(params: HikvisionParams): string {
  const host = params.host.trim().replace(/^rtsp:\/\//, '').replace(/\/.*$/, '');
  const port = params.port || 554;
  const auth = params.password 
    ? `${encodeURIComponent(params.username)}:${encodeURIComponent(params.password)}@` 
    : `${encodeURIComponent(params.username)}@`;
  const streamDigit = params.streamType === 'main' ? '1' : '2';
  const channelCode = `${params.channel * 100 + (params.streamType === 'main' ? 1 : 2)}`;
  
  return `rtsp://${auth}${host}:${port}/Streaming/Channels/${channelCode}`;
}

/**
 * Builds generic or ONVIF RTSP URL according to manufacturer presets.
 */
export function buildPresetRtspUrl(
  brand: 'hikvision' | 'dahua' | 'v380_onvif' | 'generic',
  host: string,
  port: number = 554,
  user: string = 'admin',
  pass: string = '',
  channel: number = 1,
  streamType: 'main' | 'sub' = 'main'
): string {
  const cleanHost = host.trim().replace(/^rtsp:\/\//, '').replace(/\/.*$/, '');
  const auth = pass ? `${encodeURIComponent(user)}:${encodeURIComponent(pass)}@` : `${encodeURIComponent(user)}@`;

  switch (brand) {
    case 'hikvision': {
      const code = `${channel * 100 + (streamType === 'main' ? 1 : 2)}`;
      return `rtsp://${auth}${cleanHost}:${port}/Streaming/Channels/${code}`;
    }
    case 'dahua': {
      const subType = streamType === 'main' ? 0 : 1;
      return `rtsp://${auth}${cleanHost}:${port}/cam/realmonitor?channel=${channel}&subtype=${subType}`;
    }
    case 'v380_onvif': {
      // V380 ONVIF / live RTSP path (requires firmware ONVIF enabled)
      const subType = streamType === 'main' ? 'ch0_0.264' : 'ch0_1.264';
      return `rtsp://${auth}${cleanHost}:${port}/live/${subType}`;
    }
    case 'generic':
    default:
      return `rtsp://${auth}${cleanHost}:${port}/live/ch${channel}_${streamType}`;
  }
}

/**
 * Masks the password in an RTSP URL for safe display in UI / logs.
 */
export function maskRtspUrl(url: string): string {
  if (!url) return '';
  // match rtsp://user:pass@host:port/path
  return url.replace(/rtsp:\/\/([^:]+):([^@]+)@/, 'rtsp://$1:••••••@');
}

/**
 * Validates basic RTSP URL syntax.
 */
export function validateRtspSyntax(url: string): { valid: boolean; message: string } {
  if (!url || typeof url !== 'string') {
    return { valid: false, message: 'La URL RTSP no puede estar vacía' };
  }
  const trimmed = url.trim();
  if (!trimmed.startsWith('rtsp://')) {
    return { valid: false, message: 'La URL debe comenzar con el protocolo rtsp://' };
  }
  const withoutProtocol = trimmed.substring(7);
  if (!withoutProtocol.includes('@') && !withoutProtocol.includes(':')) {
    return { valid: false, message: 'Falta el host o puerto en la dirección RTSP' };
  }
  return { valid: true, message: 'Sintaxis RTSP válida' };
}

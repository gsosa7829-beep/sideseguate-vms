import test from 'node:test';
import assert from 'node:assert/strict';
import { buildHikvisionRtspUrl, buildPresetRtspUrl, maskRtspUrl, validateRtspSyntax } from './rtspHelper.ts';
import { generateShareToken, verifyShareLink, formatExpirationText } from './tokenSecurity.ts';
import { generateMediaMtxYaml } from './mediaMtxGenerator.ts';
import { ShareLink, Camera } from './types.ts';

test('buildHikvisionRtspUrl creates standard Hikvision channel URL', () => {
  const urlMain = buildHikvisionRtspUrl({
    host: '190.86.12.34',
    port: 554,
    username: 'admin',
    password: 'password123',
    channel: 1,
    streamType: 'main'
  });
  assert.equal(urlMain, 'rtsp://admin:password123@190.86.12.34:554/Streaming/Channels/101');

  const urlSub = buildHikvisionRtspUrl({
    host: '192.168.1.100',
    port: 554,
    username: 'admin',
    password: 'pass',
    channel: 2,
    streamType: 'sub'
  });
  assert.equal(urlSub, 'rtsp://admin:pass@192.168.1.100:554/Streaming/Channels/202');
});

test('maskRtspUrl protects sensitive camera credentials in UI', () => {
  const masked = maskRtspUrl('rtsp://admin:MiClaveSecreta99@190.86.12.34:554/Streaming/Channels/101');
  assert.equal(masked, 'rtsp://admin:••••••@190.86.12.34:554/Streaming/Channels/101');
});

test('validateRtspSyntax detects valid and invalid RTSP strings', () => {
  assert.equal(validateRtspSyntax('rtsp://admin:pass@192.168.1.50:554/live').valid, true);
  assert.equal(validateRtspSyntax('http://example.com/video.mp4').valid, false);
  assert.equal(validateRtspSyntax('').valid, false);
});

test('generateShareToken produces prefixed random tokens', () => {
  const token = generateShareToken('sdg');
  assert.ok(token.startsWith('sdg_live_'));
  assert.equal(token.length, 25);
});

test('verifyShareLink correctly enforces active status and expiry', () => {
  const activeLink: ShareLink = {
    id: 'link1',
    projectId: 'p1',
    token: 'token123',
    title: 'Cliente Mixco',
    clientName: 'Don Carlos',
    cameraIds: [],
    expiresAt: new Date(Date.now() + 86400000).toISOString(), // +24 hours
    isActive: true,
    allowPtz: false,
    allowAudio: true,
    allowSnapshot: true,
    showWatermark: true,
    maxConcurrentViewers: 3,
    accessCount: 1,
    lastAccessedAt: null,
    createdAt: new Date().toISOString()
  };

  // Valid active link
  assert.equal(verifyShareLink(activeLink).valid, true);

  // Inactive link
  const inactiveLink = { ...activeLink, isActive: false };
  const resInactive = verifyShareLink(inactiveLink);
  assert.equal(resInactive.valid, false);
  assert.equal(resInactive.reason, 'inactive');

  // Expired link
  const expiredLink = { ...activeLink, expiresAt: new Date(Date.now() - 10000).toISOString() };
  const resExpired = verifyShareLink(expiredLink);
  assert.equal(resExpired.valid, false);
  assert.equal(resExpired.reason, 'expired');

  // PIN required
  const pinLink = { ...activeLink, pinCode: '4321' };
  assert.equal(verifyShareLink(pinLink).reason, 'pin_required');
  assert.equal(verifyShareLink(pinLink, '9999').reason, 'invalid_pin');
  assert.equal(verifyShareLink(pinLink, '4321').valid, true);
});

test('generateMediaMtxYaml includes camera paths and server blocks', () => {
  const dummyCameras: Camera[] = [
    {
      id: 'cam-01-mixco',
      projectId: 'p1',
      name: 'Entrada Principal',
      deviceType: 'hikvision_dvr',
      host: '190.86.12.34',
      port: 554,
      username: 'admin',
      password: 'secret',
      channel: 1,
      streamType: 'main',
      rtspUrl: 'rtsp://admin:secret@190.86.12.34:554/Streaming/Channels/101',
      status: 'online',
      fps: 25,
      resolution: '1080p',
      bitrateKbps: 2048,
      codec: 'H.264',
      locationDesc: 'Portón de ingreso vehicular',
      ptzSupported: false,
      nightVision: true
    }
  ];

  const yaml = generateMediaMtxYaml(dummyCameras);
  assert.ok(yaml.includes('paths:'));
  assert.ok(yaml.includes('Entrada Principal'));
  assert.ok(yaml.includes('Streaming/Channels/101'));
  assert.ok(yaml.includes('webrtc: yes'));
  assert.ok(yaml.includes('hls: yes'));
});

import React, { useState, useEffect } from 'react';
import { Camera, Project, ShareLink, AccessLog, NavigationTab } from './lib/types';
import { storage } from './lib/storage';
import { maskRtspUrl } from './lib/rtspHelper';
import { formatExpirationText } from './lib/tokenSecurity';
import { generateMediaMtxYaml } from './lib/mediaMtxGenerator';
import { LiveCameraPlayer } from './components/LiveCameraPlayer';
import { ClientLivePortal } from './components/ClientLivePortal';
import { ShareLinkModal } from './components/ShareLinkModal';
import { CameraModal } from './components/CameraModal';
import { ProjectModal } from './components/ProjectModal';
import { Sidebar } from './components/Sidebar';
import { TopNavbar } from './components/TopNavbar';
import { VideoWall } from './components/VideoWall';
import { PatrolView } from './components/PatrolView';
import { AccessAuditView } from './components/AccessAuditView';
import { SadpScannerView } from './components/SadpScannerView';
import { ZeroStorageView } from './components/ZeroStorageView';
import { MobileSimulatorModal } from './components/MobileSimulatorModal';
import { ArchitectureTab } from './components/ArchitectureTab';

import { 
  Shield, 
  Cctv, 
  Link2, 
  Building2, 
  Workflow, 
  Plus, 
  ExternalLink, 
  Copy, 
  Check, 
  Power, 
  Trash2, 
  Edit3, 
  Eye, 
  Key, 
  Radio, 
  RefreshCw, 
  Search, 
  Grid2X2, 
  Square,
  AlertTriangle,
  Lock,
  Smartphone,
  PhoneCall,
  Clock,
  Sparkles,
  Download,
  Share2,
  MessageCircle,
  CheckCircle2,
  FileCode,
  Server,
  Play,
  RotateCw,
  LayoutGrid
} from 'lucide-react';

export default function App() {
  // Navigation & State
  const [activeTab, setActiveTab] = useState<NavigationTab>('videowall');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileSimulatorOpen, setIsMobileSimulatorOpen] = useState(false);

  // Entities
  const [projects, setProjects] = useState<Project[]>([]);
  const [cameras, setCameras] = useState<Camera[]>([]);
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [accessLogs, setAccessLogs] = useState<AccessLog[]>([]);

  // Selected camera for single camera view
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');

  // Client view simulation / token routing
  const [clientTokenView, setClientTokenView] = useState<string | null>(null);

  // Modals state
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [editingShareLink, setEditingShareLink] = useState<ShareLink | null>(null);

  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [editingCamera, setEditingCamera] = useState<Camera | null>(null);

  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // Search & filter
  const [globalSearchTerm, setGlobalSearchTerm] = useState('');
  const [cameraSearch, setCameraSearch] = useState('');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [copiedYaml, setCopiedYaml] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load data from persistent storage
  useEffect(() => {
    const loadedProjects = storage.getProjects();
    const loadedCameras = storage.getCameras();
    const loadedLinks = storage.getShareLinks();
    const loadedLogs = storage.getAccessLogs();

    setProjects(loadedProjects);
    setCameras(loadedCameras);
    setShareLinks(loadedLinks);
    setAccessLogs(loadedLogs);

    if (loadedCameras.length > 0) {
      setSelectedCameraId(loadedCameras[0].id);
    }

    // Check URL query param ?token=xyz or hash #token=xyz
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get('token');
    if (urlToken) {
      setClientTokenView(urlToken);
    } else {
      const hash = window.location.hash;
      if (hash.startsWith('#token=')) {
        setClientTokenView(hash.replace('#token=', ''));
      }
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Save changes to storage
  const handleSaveCamera = (camera: Camera) => {
    let updated: Camera[];
    const exists = cameras.some((c) => c.id === camera.id);
    if (exists) {
      updated = cameras.map((c) => (c.id === camera.id ? camera : c));
      showToast('Cámara actualizada exitosamente');
    } else {
      updated = [camera, ...cameras];
      showToast('Cámara registrada en el Gateway');
    }
    setCameras(updated);
    storage.saveCameras(updated);
  };

  const handleDeleteCamera = (id: string) => {
    if (confirm('¿Está seguro de eliminar esta cámara del sistema?')) {
      const updated = cameras.filter((c) => c.id !== id);
      setCameras(updated);
      storage.saveCameras(updated);
      if (selectedCameraId === id && updated.length > 0) {
        setSelectedCameraId(updated[0].id);
      }
      showToast('Cámara eliminada');
    }
  };

  const handleSaveShareLink = (link: ShareLink) => {
    let updated: ShareLink[];
    const exists = shareLinks.some((l) => l.id === link.id);
    if (exists) {
      updated = shareLinks.map((l) => (l.id === link.id ? link : l));
      showToast('Enlace de cliente actualizado');
    } else {
      updated = [link, ...shareLinks];
      showToast('Enlace generado con éxito');
    }
    setShareLinks(updated);
    storage.saveShareLinks(updated);
  };

  const handleToggleLinkActive = (id: string) => {
    const updated = shareLinks.map((l) => {
      if (l.id === id) {
        const nextState = !l.isActive;
        showToast(nextState ? 'Enlace activado para el cliente' : 'Enlace desactivado temporalmente');
        return { ...l, isActive: nextState };
      }
      return l;
    });
    setShareLinks(updated);
    storage.saveShareLinks(updated);
  };

  const handleExpireLinkNow = (id: string) => {
    const updated = shareLinks.map((l) => {
      if (l.id === id) {
        showToast('Enlace marcado como expirado');
        return { ...l, expiresAt: new Date(Date.now() - 1000).toISOString() };
      }
      return l;
    });
    setShareLinks(updated);
    storage.saveShareLinks(updated);
  };

  const handleDeleteShareLink = (id: string) => {
    if (confirm('¿Eliminar este enlace privado permanentemente?')) {
      const updated = shareLinks.filter((l) => l.id !== id);
      setShareLinks(updated);
      storage.saveShareLinks(updated);
      showToast('Enlace eliminado');
    }
  };

  const handleSaveProject = (project: Project) => {
    let updated: Project[];
    const exists = projects.some((p) => p.id === project.id);
    if (exists) {
      updated = projects.map((p) => (p.id === project.id ? project : p));
      showToast('Proyecto actualizado');
    } else {
      updated = [project, ...projects];
      showToast('Proyecto registrado');
    }
    setProjects(updated);
    storage.saveProjects(updated);
  };

  const handleCopyLinkUrl = (token: string) => {
    const baseUrl = window.location.origin + window.location.pathname;
    const fullUrl = `${baseUrl}?token=${token}`;
    navigator.clipboard.writeText(fullUrl);
    setCopiedToken(token);
    showToast('Enlace privado copiado al portapapeles');
    setTimeout(() => setCopiedToken(null), 2500);
  };

  const getWhatsAppShareUrl = (link: ShareLink) => {
    const baseUrl = window.location.origin + window.location.pathname;
    const fullUrl = `${baseUrl}?token=${link.token}`;
    const text = encodeURIComponent(
      `Hola ${link.clientName}, aquí tienes tu enlace privado para ver las cámaras en vivo desde tu navegador:\n\n${fullUrl}\n\nPuedes abrirlo directo en tu celular o PC sin descargar ninguna app.`
    );
    return `https://api.whatsapp.com/send?text=${text}`;
  };

  // If in Client Portal View directly
  if (clientTokenView) {
    const currentLink = shareLinks.find((l) => l.token === clientTokenView);
    const currentProj = projects.find((p) => p.id === currentLink?.projectId);
    return (
      <ClientLivePortal
        shareLink={currentLink}
        cameras={cameras}
        project={currentProj}
        isAdminPreview={true}
        onBackToAdmin={() => {
          setClientTokenView(null);
          window.history.pushState({}, '', window.location.pathname);
        }}
      />
    );
  }

  // Filtered cameras
  const filteredCameras = cameras.filter((cam) => {
    const query = globalSearchTerm || cameraSearch;
    const matchesSearch = 
      cam.name.toLowerCase().includes(query.toLowerCase()) ||
      cam.locationDesc.toLowerCase().includes(query.toLowerCase()) ||
      cam.host.includes(query);
    const matchesProj = projectFilter === 'all' || cam.projectId === projectFilter;
    return matchesSearch && matchesProj;
  });

  const selectedCamera = cameras.find((c) => c.id === selectedCameraId) || cameras[0];
  const onlineCamerasCount = cameras.filter((c) => c.status === 'online').length;
  const mediamtxYaml = generateMediaMtxYaml(cameras);

  return (
    <div className="flex h-screen w-screen bg-neutral-950 text-neutral-100 overflow-hidden font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-blue-600 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl animate-fade-in flex items-center gap-2 border border-blue-400/40">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Comprehensive Left Sidebar Navigation */}
      <Sidebar
        currentTab={activeTab}
        onSelectTab={(tab) => setActiveTab(tab)}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        camerasCount={cameras.length}
        onlineCount={onlineCamerasCount}
        shareLinksCount={shareLinks.length}
        projectsCount={projects.length}
        onOpenMobilePreview={() => setIsMobileSimulatorOpen(true)}
      />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* 2. Top Header Bar with Breadcrumbs, Search & KPIs */}
        <TopNavbar
          currentTab={activeTab}
          onOpenNewLink={() => {
            setEditingShareLink(null);
            setIsShareModalOpen(true);
          }}
          onOpenNewCamera={() => {
            setEditingCamera(null);
            setIsCameraModalOpen(true);
          }}
          onOpenMobilePreview={() => setIsMobileSimulatorOpen(true)}
          searchTerm={globalSearchTerm}
          onSearchChange={(val) => setGlobalSearchTerm(val)}
          camerasOnline={onlineCamerasCount}
          totalCameras={cameras.length}
          totalLinks={shareLinks.length}
        />

        {/* 3. Main Scrollable Canvas for Active Tab View */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* VIEW 1: Muro de Video (Matrix Multicámara) */}
          {activeTab === 'videowall' && (
            <VideoWall
              cameras={cameras}
              onSelectCamera={(id) => {
                setSelectedCameraId(id);
                setActiveTab('single_camera');
              }}
              onOpenNewCamera={() => {
                setEditingCamera(null);
                setIsCameraModalOpen(true);
              }}
              onGenerateLink={(cam) => {
                setEditingShareLink(null);
                setIsShareModalOpen(true);
              }}
            />
          )}

          {/* VIEW 2: Cámara en Detalle con PTZ */}
          {activeTab === 'single_camera' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                <div className="lg:col-span-3 flex flex-col gap-3">
                  {selectedCamera ? (
                    <LiveCameraPlayer
                      camera={selectedCamera}
                      allowPtz={true}
                      allowAudio={true}
                      allowSnapshot={true}
                      showWatermark={false}
                    />
                  ) : (
                    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-12 text-center text-xs text-neutral-400">
                      No hay cámaras seleccionadas.
                    </div>
                  )}

                  {selectedCamera && (
                    <div className="bg-neutral-900/70 border border-neutral-800/80 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-white text-sm">{selectedCamera.name}</h3>
                          <span className="font-mono text-[11px] text-neutral-400">
                            {selectedCamera.deviceType === 'hikvision_dvr' ? 'Hikvision DVR' : selectedCamera.deviceType === 'hikvision_ip' ? 'Hikvision IP' : 'T-DAY 4G'}
                          </span>
                        </div>
                        <p className="text-neutral-400 text-xs mb-1">{selectedCamera.locationDesc}</p>
                        <p className="text-[11px] font-mono text-neutral-500">
                          RTSP: {maskRtspUrl(selectedCamera.rtspUrl)}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => {
                            setEditingCamera(selectedCamera);
                            setIsCameraModalOpen(true);
                          }}
                          className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-300 hover:text-white border border-neutral-700/80 rounded-lg transition flex items-center gap-1.5 text-xs font-medium"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-neutral-400" />
                          <span>Configurar</span>
                        </button>
                        <button
                          onClick={() => {
                            setEditingShareLink(null);
                            setIsShareModalOpen(true);
                          }}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition flex items-center gap-1.5 text-xs font-semibold shadow-sm"
                        >
                          <Link2 className="w-3.5 h-3.5" />
                          <span>Generar Enlace</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Sidebar Camera Switcher */}
                <div className="lg:col-span-1 space-y-2">
                  <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider px-1 font-mono">
                    Seleccionar Cámara ({cameras.length})
                  </div>
                  <div className="space-y-1.5">
                    {cameras.map((cam) => {
                      const isSelected = cam.id === selectedCameraId;
                      return (
                        <div
                          key={cam.id}
                          onClick={() => setSelectedCameraId(cam.id)}
                          className={`p-3 rounded-xl border cursor-pointer transition flex flex-col gap-1.5 ${
                            isSelected
                              ? 'bg-neutral-900 border-neutral-700 text-white shadow-sm'
                              : 'bg-neutral-950/60 border-neutral-850 text-neutral-400 hover:bg-neutral-900/60 hover:border-neutral-750 hover:text-neutral-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-xs truncate max-w-[170px] text-white">
                              {cam.name}
                            </span>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              cam.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'
                            }`} />
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-neutral-400">
                            <span className="truncate">{cam.locationDesc}</span>
                            <span className="font-mono text-[10px] text-neutral-500">CH{cam.channel}</span>
                          </div>
                          <div className="flex items-center justify-between text-[10px] font-mono text-neutral-500 pt-1.5 border-t border-neutral-800/60">
                            <span>{cam.resolution.split(' ')[0]}</span>
                            <span className="text-neutral-400">{cam.fps} FPS</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW 3: Patrullaje Continuo */}
          {activeTab === 'patrol' && (
            <PatrolView
              cameras={cameras}
              onGenerateLink={(cam) => {
                setEditingShareLink(null);
                setIsShareModalOpen(true);
              }}
            />
          )}

          {/* VIEW 4: Enlaces Web Temporales */}
          {activeTab === 'share_links' && (
            <div className="space-y-4">
              <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Link2 className="w-4 h-4 text-neutral-300" />
                    Enlaces Privados para Clientes (Zero Install)
                  </h2>
                  <p className="text-xs text-neutral-400 mt-0.5 max-w-2xl leading-relaxed">
                    Genera accesos temporales para clientes con soporte directo para enviar por WhatsApp. Se abren en Chrome, Safari o móvil sin descargar programas.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setEditingShareLink(null);
                    setIsShareModalOpen(true);
                  }}
                  className="px-3.5 py-2 bg-white hover:bg-neutral-100 text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition shrink-0"
                >
                  <Plus className="w-3.5 h-3.5 text-neutral-700" />
                  <span>Generar Nuevo Enlace</span>
                </button>
              </div>

              {/* Links Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {shareLinks.map((link) => {
                  const proj = projects.find((p) => p.id === link.projectId);
                  const assignedCams = cameras.filter((c) => 
                    link.cameraIds && link.cameraIds.length > 0 ? link.cameraIds.includes(c.id) : c.projectId === link.projectId
                  );
                  const isExpired = link.expiresAt ? new Date(link.expiresAt).getTime() <= Date.now() : false;

                  return (
                    <div
                      key={link.id}
                      className={`bg-neutral-900/70 border rounded-xl p-4 flex flex-col justify-between shadow-sm transition relative ${
                        !link.isActive || isExpired
                          ? 'border-neutral-850 opacity-75'
                          : 'border-neutral-800/80 hover:border-neutral-700'
                      }`}
                    >
                      <div>
                        {/* Status row without loud pill badges */}
                        <div className="flex items-center justify-between mb-3 text-xs">
                          <div className="flex items-center gap-1.5">
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              !link.isActive ? 'bg-neutral-500' : isExpired ? 'bg-red-500' : 'bg-emerald-400'
                            }`} />
                            <span className="font-medium text-neutral-300 text-xs">
                              {!link.isActive ? 'Desactivado' : isExpired ? 'Expirado' : 'Activo en Vivo'}
                            </span>
                          </div>

                          {link.pinCode && (
                            <span className="text-[11px] text-neutral-400 flex items-center gap-1 font-mono">
                              <Lock className="w-3 h-3 text-neutral-500" />
                              PIN: {link.pinCode}
                            </span>
                          )}
                        </div>

                        {/* Title & Client */}
                        <div className="mb-3">
                          <h3 className="font-semibold text-sm text-white leading-snug mb-0.5">
                            {link.title}
                          </h3>
                          <div className="text-xs text-neutral-400 flex items-center gap-1.5">
                            <span className="text-neutral-300 font-medium">{link.clientName}</span>
                            {proj && <span className="text-neutral-500">· {proj.name}</span>}
                          </div>
                        </div>

                        {/* Meta info block */}
                        <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850 text-xs space-y-1.5 mb-3.5">
                          <div className="flex items-center justify-between text-neutral-400">
                            <span>Cámaras asignadas:</span>
                            <span className="text-white font-medium">{assignedCams.length}</span>
                          </div>
                          <div className="flex items-center justify-between text-neutral-400">
                            <span>Vencimiento:</span>
                            <span className={`font-medium ${isExpired ? 'text-red-400' : 'text-neutral-200'}`}>
                              {formatExpirationText(link.expiresAt)}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-neutral-400">
                            <span>Accesos cliente:</span>
                            <span className="text-neutral-400 font-mono text-[11px]">{link.accessCount} visitas</span>
                          </div>
                        </div>

                        {/* Clean Permissions row */}
                        <div className="flex flex-wrap items-center gap-2 mb-3.5 text-[11px] text-neutral-400">
                          {link.allowPtz && <span>PTZ</span>}
                          {link.allowAudio && <span>· Audio</span>}
                          {link.allowSnapshot && <span>· Capturas</span>}
                          {link.showWatermark && <span>· Marca de Agua</span>}
                        </div>
                      </div>

                      {/* Action buttons footer */}
                      <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1">
                          <button
                            aria-label={link.isActive ? 'Desactivar enlace' : 'Activar enlace'}
                            onClick={() => handleToggleLinkActive(link.id)}
                            className={`p-1.5 rounded-lg border text-xs transition ${
                              link.isActive
                                ? 'bg-neutral-800/80 border-neutral-700/80 text-neutral-400 hover:text-white'
                                : 'bg-emerald-950/80 border-emerald-800 text-emerald-400'
                            }`}
                            title={link.isActive ? 'Desactivar Enlace' : 'Activar Enlace'}
                          >
                            <Power className="w-3.5 h-3.5" />
                          </button>

                          {link.isActive && !isExpired && (
                            <button
                              aria-label="Forzar expiración del enlace"
                              onClick={() => handleExpireLinkNow(link.id)}
                              className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700/80 text-neutral-400 hover:text-amber-400 rounded-lg text-xs transition"
                              title="Expirar Enlace Ahora"
                            >
                              <Clock className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            aria-label="Editar enlace"
                            onClick={() => {
                              setEditingShareLink(link);
                              setIsShareModalOpen(true);
                            }}
                            className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700/80 text-neutral-400 hover:text-white rounded-lg text-xs transition"
                            title="Editar"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            aria-label="Eliminar enlace privado"
                            onClick={() => handleDeleteShareLink(link.id)}
                            className="p-1.5 bg-neutral-800/80 hover:bg-red-950/80 border border-neutral-700/80 text-neutral-400 hover:text-red-400 rounded-lg text-xs transition"
                            title="Eliminar"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Send via WhatsApp */}
                          <a
                            href={getWhatsAppShareUrl(link)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 bg-neutral-800/80 hover:bg-emerald-950 text-neutral-400 hover:text-emerald-400 border border-neutral-700/80 rounded-lg text-xs transition flex items-center justify-center"
                            title="Enviar enlace por WhatsApp al cliente"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                          </a>

                          {/* Copy Link */}
                          <button
                            onClick={() => handleCopyLinkUrl(link.token)}
                            className="px-2.5 py-1.5 bg-neutral-800/80 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-medium flex items-center gap-1 border border-neutral-700/80 transition"
                            title="Copiar URL para el cliente"
                          >
                            {copiedToken === link.token ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
                            <span>{copiedToken === link.token ? 'Copiado' : 'Copiar'}</span>
                          </button>

                          {/* Open as Client */}
                          <button
                            onClick={() => setClientTokenView(link.token)}
                            className="px-2.5 py-1.5 bg-neutral-100 hover:bg-white text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1 transition shadow-sm"
                            title="Probar vista de cliente"
                          >
                            <Eye className="w-3.5 h-3.5 text-neutral-700" />
                            <span>Abrir</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 5: Clientes & Ubicaciones */}
          {activeTab === 'clients_projects' && (
            <div className="space-y-4">
              <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-neutral-300" />
                    Directorio de Clientes & Proyectos
                  </h2>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Administración de contratos, presupuestos asignados y sedes de clientes.
                  </p>
                </div>

                <button
                  onClick={() => {
                    setEditingProject(null);
                    setIsProjectModalOpen(true);
                  }}
                  className="px-3.5 py-2 bg-white hover:bg-neutral-100 text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5 text-neutral-700" />
                  <span>Nuevo Proyecto</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map((proj) => {
                  const projCameras = cameras.filter((c) => c.projectId === proj.id);
                  const projLinks = shareLinks.filter((l) => l.projectId === proj.id);

                  return (
                    <div
                      key={proj.id}
                      className="bg-neutral-900/70 border border-neutral-800/80 rounded-xl p-4 shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium text-neutral-400">
                            {proj.status === 'activo' && 'Activo en Vivo'}
                            {proj.status === 'en_instalacion' && 'En Instalación'}
                            {proj.status === 'cotizado' && 'Cotizado'}
                            {proj.status === 'completado' && 'Completado'}
                          </span>
                          <span className="text-xs font-bold text-emerald-400 font-mono">
                            Q {proj.budgetQ.toLocaleString()}
                          </span>
                        </div>

                        <h3 className="font-semibold text-sm text-white mb-0.5">{proj.name}</h3>
                        <p className="text-xs text-neutral-400 mb-3">{proj.location}</p>

                        <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850 text-xs space-y-1.5 mb-3">
                          <div className="flex justify-between text-neutral-400">
                            <span>Cliente:</span>
                            <span className="text-white font-medium">{proj.clientName}</span>
                          </div>
                          <div className="flex justify-between text-neutral-400">
                            <span>Teléfono / WhatsApp:</span>
                            <span className="text-emerald-400 font-mono">{proj.clientPhone}</span>
                          </div>
                          <div className="flex justify-between text-neutral-400">
                            <span>Plazo de Entrega:</span>
                            <span className="text-neutral-200">{proj.targetWeeks} Semanas</span>
                          </div>
                        </div>

                        <div className="text-xs text-neutral-400 bg-neutral-950/40 p-2.5 rounded-lg border border-neutral-850 mb-3 leading-relaxed">
                          <span className="text-neutral-500 block text-[10px] uppercase font-mono mb-0.5">Equipamiento</span>
                          {proj.equipmentNotes}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                        <div className="text-neutral-400">
                          <span className="text-white font-medium">{projCameras.length}</span> Cámaras · <span className="text-white font-medium">{projLinks.length}</span> Enlaces
                        </div>

                        <button
                          onClick={() => {
                            setEditingProject(proj);
                            setIsProjectModalOpen(true);
                          }}
                          className="px-3 py-1 bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white rounded-lg transition text-xs font-medium border border-neutral-750"
                        >
                          Editar
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 6: Auditoría de Accesos */}
          {activeTab === 'access_audit' && (
            <AccessAuditView logs={accessLogs} shareLinks={shareLinks} />
          )}

          {/* VIEW 7: Catálogo de Cámaras & DVRs */}
          {activeTab === 'devices_catalog' && (
            <div className="space-y-4">
              {/* Filter & Add Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-neutral-900/60 border border-neutral-800/80 p-3 rounded-xl">
                <div className="flex items-center gap-2 flex-1 max-w-md bg-neutral-950/60 px-3 py-1.5 rounded-lg border border-neutral-850">
                  <Search className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                  <input
                    type="text"
                    value={cameraSearch}
                    onChange={(e) => setCameraSearch(e.target.value)}
                    placeholder="Buscar por nombre, IP o modelo..."
                    className="bg-transparent border-none text-xs text-white placeholder-neutral-500 focus:outline-none w-full"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={projectFilter}
                    onChange={(e) => setProjectFilter(e.target.value)}
                    className="bg-neutral-950 border border-neutral-800 text-xs text-neutral-300 rounded-lg px-3 py-1.5 focus:outline-none"
                  >
                    <option value="all">Todos los proyectos</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>

                  <button
                    onClick={() => {
                      setEditingCamera(null);
                      setIsCameraModalOpen(true);
                    }}
                    className="px-3.5 py-1.5 bg-white hover:bg-neutral-100 text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-sm shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5 text-neutral-700" />
                    <span>Nueva Cámara</span>
                  </button>
                </div>
              </div>

              {/* Cameras Table */}
              <div className="bg-neutral-900/70 border border-neutral-800/80 rounded-xl overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-950 text-neutral-500 uppercase font-mono text-[10px] border-b border-neutral-800/80">
                      <tr>
                        <th className="py-2.5 px-4 font-medium">Estado</th>
                        <th className="py-2.5 px-4 font-medium">Nombre / Ubicación</th>
                        <th className="py-2.5 px-4 font-medium">Hardware & Canal</th>
                        <th className="py-2.5 px-4 font-medium">URL RTSP</th>
                        <th className="py-2.5 px-4 font-medium">Formato</th>
                        <th className="py-2.5 px-4 text-right font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-850">
                      {filteredCameras.map((cam) => {
                        return (
                          <tr key={cam.id} className="hover:bg-neutral-850/40 transition">
                            <td className="py-3 px-4 whitespace-nowrap">
                              <span className="inline-flex items-center gap-1.5 text-xs">
                                <span className={`w-1.5 h-1.5 rounded-full ${cam.status === 'online' ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                                <span className="text-neutral-300 font-medium text-[11px]">
                                  {cam.status === 'online' ? 'Online' : 'Aviso 4G'}
                                </span>
                              </span>
                            </td>

                            <td className="py-3 px-4">
                              <div className="font-medium text-white">{cam.name}</div>
                              <div className="text-[11px] text-neutral-400">{cam.locationDesc}</div>
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap">
                              <div className="text-neutral-300 font-medium text-xs">
                                {cam.deviceType === 'hikvision_dvr' && 'Hikvision DVR'}
                                {cam.deviceType === 'hikvision_ip' && 'Hikvision IP POE'}
                                {cam.deviceType === 'v380_4g' && 'T-DAY 4G V380'}
                                {cam.deviceType === 'generic_rtsp' && 'Genérica RTSP'}
                              </div>
                              <div className="text-[10px] text-neutral-500 font-mono">
                                Canal {cam.channel} · {cam.streamType === 'main' ? 'Principal' : 'Subflujo'}
                              </div>
                            </td>

                            <td className="py-3 px-4 max-w-xs">
                              <div className="font-mono text-[11px] text-neutral-400 truncate bg-neutral-950/80 px-2.5 py-1 rounded border border-neutral-850">
                                {maskRtspUrl(cam.rtspUrl)}
                              </div>
                            </td>

                            <td className="py-3 px-4 whitespace-nowrap text-neutral-400">
                              <div>{cam.resolution}</div>
                              <div className="text-[10px] font-mono text-neutral-500">
                                {cam.fps} FPS · {cam.codec}
                              </div>
                            </td>

                            <td className="py-3 px-4 text-right whitespace-nowrap">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  aria-label="Ver cámara en monitor"
                                  onClick={() => {
                                    setSelectedCameraId(cam.id);
                                    setActiveTab('single_camera');
                                  }}
                                  className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-lg transition"
                                  title="Ver en Monitor"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>

                                <button
                                  aria-label="Editar cámara"
                                  onClick={() => {
                                    setEditingCamera(cam);
                                    setIsCameraModalOpen(true);
                                  }}
                                  className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-lg transition"
                                  title="Editar"
                                >
                                  <Edit3 className="w-3.5 h-3.5" />
                                </button>

                                <button
                                  aria-label="Eliminar cámara"
                                  onClick={() => handleDeleteCamera(cam.id)}
                                  className="p-1.5 bg-neutral-800/80 hover:bg-red-950/80 text-neutral-400 hover:text-red-400 rounded-lg transition"
                                  title="Eliminar"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* VIEW 8: Escáner SADP Tool & Red Local */}
          {activeTab === 'sadp_scanner' && (
            <SadpScannerView />
          )}

          {/* VIEW 9: Servidor Windows 24/7 */}
          {activeTab === 'windows_server' && (
            <ArchitectureTab cameras={cameras} />
          )}

          {/* VIEW 10: Cero Almacenamiento en Nube */}
          {activeTab === 'zero_storage' && (
            <ZeroStorageView />
          )}

          {/* VIEW 11: Configurador mediamtx.yml */}
          {activeTab === 'mediamtx_config' && (
            <div className="space-y-4">
              <div className="bg-neutral-900/60 border border-neutral-850 p-4 rounded-xl flex items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-blue-400" />
                    Archivo de Configuración mediamtx.yml
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Generado automáticamente para Windows con las {cameras.length} cámaras Hikvision registradas.
                  </p>
                </div>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(mediamtxYaml);
                    setCopiedYaml(true);
                    setTimeout(() => setCopiedYaml(false), 2000);
                  }}
                  className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 border border-neutral-700/80 transition"
                >
                  {copiedYaml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedYaml ? 'Copiado' : 'Copiar YAML'}</span>
                </button>
              </div>

              <pre className="bg-neutral-950 border border-neutral-850 text-emerald-400 font-mono text-[11px] p-4 rounded-xl overflow-x-auto max-h-[520px] leading-relaxed">
                {mediamtxYaml}
              </pre>
            </div>
          )}
        </main>
      </div>

      {/* 4. Interactive Smartphone Preview Simulator Modal */}
      <MobileSimulatorModal
        isOpen={isMobileSimulatorOpen}
        onClose={() => setIsMobileSimulatorOpen(false)}
        shareLinks={shareLinks}
        cameras={cameras}
        projects={projects}
      />

      {/* Persistent Modals */}
      <ShareLinkModal
        isOpen={isShareModalOpen}
        onClose={() => {
          setIsShareModalOpen(false);
          setEditingShareLink(null);
        }}
        onSave={handleSaveShareLink}
        projects={projects}
        cameras={cameras}
        initialLink={editingShareLink}
      />

      <CameraModal
        isOpen={isCameraModalOpen}
        onClose={() => {
          setIsCameraModalOpen(false);
          setEditingCamera(null);
        }}
        onSave={handleSaveCamera}
        projects={projects}
        initialCamera={editingCamera}
      />

      <ProjectModal
        isOpen={isProjectModalOpen}
        onClose={() => {
          setIsProjectModalOpen(false);
          setEditingProject(null);
        }}
        onSave={handleSaveProject}
        initialProject={editingProject}
      />
    </div>
  );
}

import React, { useState } from 'react';
import { 
  SearchCode, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  RefreshCw, 
  Wifi, 
  Radio, 
  Check, 
  Copy,
  ExternalLink,
  Lock,
  Unlock
} from 'lucide-react';
import { CLIENT_HIKVISION_HARDWARE } from '../lib/initialData';

export const SadpScannerView: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [testedPorts, setTestedPorts] = useState<Record<string, boolean>>({
    '554': true,
    '8000': true,
    '80': true
  });
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleRescan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
    }, 1200);
  };

  return (
    <div className="space-y-4">
      {/* Header Banner */}
      <div className="bg-neutral-900/60 border border-neutral-850 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <SearchCode className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Escáner SADP Tool & Diagnóstico de Red Local Hikvision
            </h3>
          </div>
          <p className="text-xs text-neutral-400 max-w-2xl leading-relaxed">
            Diagnóstico de los equipos detectados en la red local del cliente según la captura del software oficial Hikvision SADP Tool.
          </p>
        </div>

        <button
          onClick={handleRescan}
          disabled={isScanning}
          className="px-3.5 py-2 bg-neutral-800 hover:bg-neutral-750 text-white rounded-lg text-xs font-medium flex items-center gap-2 transition border border-neutral-700/80 shadow-sm"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isScanning ? 'animate-spin' : ''}`} />
          <span>{isScanning ? 'Escaneando LAN...' : 'Volver a Escanear'}</span>
        </button>
      </div>

      {/* Primary SADP Inspection Card (Model from client's SADP photo) */}
      <div className="bg-neutral-900/70 border border-neutral-850 rounded-xl p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <div>
              <div className="font-bold text-white text-sm flex items-center gap-2">
                <span>Hikvision iDS-7108HQHI-M1/S0 (8 Canales AcuSense)</span>
                <span className="px-2 py-0.2 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  ACTIVO
                </span>
              </div>
              <p className="text-xs text-neutral-400 font-mono">
                Número de Serie: L18365299 · MAC: e0:ba:ad:cd:bc:05
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopy('rtsp://vi1fdr:Dvr232323@192.168.1.41:554/Streaming/Channels/101', 'sadp_rtsp')}
              className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-300 rounded-lg text-xs font-mono flex items-center gap-1.5 border border-neutral-700/80 transition"
            >
              {copiedKey === 'sadp_rtsp' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-400" />}
              <span>{copiedKey === 'sadp_rtsp' ? 'Copiado' : 'Copiar RTSP :554'}</span>
            </button>
          </div>
        </div>

        {/* Network Parameters Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850">
            <span className="text-[10px] text-neutral-500 block">IP LOCAL (IPv4)</span>
            <span className="text-emerald-400 font-bold text-sm">192.168.1.41</span>
          </div>

          <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850">
            <span className="text-[10px] text-neutral-500 block">PUERTA DE ENLACE (ROUTER)</span>
            <span className="text-white font-bold text-sm">192.168.1.1</span>
          </div>

          <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850">
            <span className="text-[10px] text-neutral-500 block">PUERTO RTSP STREAM</span>
            <span className="text-sky-400 font-bold text-sm">TCP 554</span>
          </div>

          <div className="bg-neutral-950/80 p-3 rounded-lg border border-neutral-850">
            <span className="text-[10px] text-neutral-500 block">PUERTO SDK HIKVISION</span>
            <span className="text-purple-400 font-bold text-sm">TCP 8000</span>
          </div>
        </div>

        {/* Technical Guidance & Warnings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-1">
          {/* Warning 1: DHCP */}
          <div className="bg-amber-950/20 border border-amber-800/40 p-3 rounded-lg text-amber-200 leading-relaxed space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Ajuste Requerido en SADP: Desmarcar DHCP</span>
            </div>
            <p className="text-[11px] text-amber-200/90">
              En la captura de SADP la casilla <strong>Enable DHCP</strong> está marcada. El técnico debe <strong>desmarcarla</strong> en el software SADP y guardar para que la IP <code>192.168.1.41</code> quede fija para siempre y no cambie al reiniciar el router.
            </p>
          </div>

          {/* Warning 2: Stream Encryption */}
          <div className="bg-blue-950/20 border border-blue-800/40 p-3 rounded-lg text-blue-200 leading-relaxed space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-blue-300">
              <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
              <span>Código de Verificación: HELGDM</span>
            </div>
            <p className="text-[11px] text-blue-200/90">
              En los DVRs AcuSense viene activo el <em>Cifrado de Flujo</em>. En el menú del DVR (Red &gt; Ajustes Avanzados &gt; Acceso a Plataforma), desmarcar <strong>Cifrado de Flujo</strong> ingresando <code className="text-white font-bold font-mono">HELGDM</code> para permitir el remuxing web directo.
            </p>
          </div>
        </div>
      </div>

      {/* Secondary Hardware Identified from Client Photos */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* DVR 2: iDS-7204HUHI-M1/S */}
        <div className="bg-neutral-900/60 border border-neutral-850 rounded-xl p-4 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-sm">DVR iDS-7204HUHI-M1/S (4 Canales)</span>
            <span className="text-[10px] font-mono text-neutral-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
              FIRMWARE V4.75.013
            </span>
          </div>
          <p className="text-neutral-400 leading-relaxed text-[11px]">
            Número de serie: <code className="text-neutral-300 font-mono">0420240307CCWRFB2200254WCVU</code>. Hardware <code>0xc0fbe00</code>. AcuSense TurboHD con detección humana/vehicular.
          </p>
          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400">
            <span>Usuario: vi1fdr</span>
            <span className="text-emerald-400 font-semibold">RTSP /Channels/101</span>
          </div>
        </div>

        {/* DVR 3: DS-7108HGHI-F1/N */}
        <div className="bg-neutral-900/60 border border-neutral-850 rounded-xl p-4 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-sm">DVR DS-7108HGHI-F1/N (8 Canales)</span>
            <span className="text-[10px] font-mono text-neutral-400 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800">
              FABRICACIÓN 12/2020
            </span>
          </div>
          <p className="text-neutral-400 leading-relaxed text-[11px]">
            Número de serie: <code className="text-neutral-300 font-mono">F30392314</code>. Equipo TurboHD de 8 puertos BNC analógicos con soporte para substream 720p/4CIF en RTSP.
          </p>
          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400">
            <span>Usuario: vi1fdr</span>
            <span className="text-emerald-400 font-semibold">RTSP /Channels/102</span>
          </div>
        </div>
      </div>
    </div>
  );
};

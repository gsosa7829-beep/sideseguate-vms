import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { Camera } from '../lib/types';
import { 
  Maximize2, 
  Minimize2, 
  Volume2, 
  VolumeX, 
  Camera as CameraIcon, 
  Compass, 
  Moon, 
  Sun, 
  ZoomIn, 
  ZoomOut, 
  RefreshCw,
  AlertTriangle,
  Radio,
  Eye
} from 'lucide-react';

interface LiveCameraPlayerProps {
  camera: Camera;
  allowPtz?: boolean;
  allowAudio?: boolean;
  allowSnapshot?: boolean;
  showWatermark?: boolean;
  watermarkText?: string;
  isCompact?: boolean;
  autoPlay?: boolean;
}

export const LiveCameraPlayer: React.FC<LiveCameraPlayerProps> = ({
  camera,
  allowPtz = true,
  allowAudio = true,
  allowSnapshot = true,
  showWatermark = true,
  watermarkText,
  isCompact = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [digitalZoom, setDigitalZoom] = useState(1);
  const [nightVision, setNightVision] = useState(camera.nightVision || false);
  const [ptzPan, setPtzPan] = useState(0); // -100 to 100
  const [ptzTilt, setPtzTilt] = useState(0); // -50 to 50
  const [ptzZoom, setPtzZoom] = useState(1);
  const [showPtzControls, setShowPtzControls] = useState(false);
  const [isLiveActive, setIsLiveActive] = useState(true);
  const [snapshotToast, setSnapshotToast] = useState<string | null>(null);
  const [metrics, setMetrics] = useState({
    fps: camera.fps || 25,
    bitrate: camera.bitrateKbps || 2048,
    latencyMs: 180 + Math.floor(Math.random() * 80)
  });

  const animFrameRef = useRef<number | null>(null);

  // If camera has real HLS stream
  const hasHls = !!camera.hlsStreamUrl;

  useEffect(() => {
    if (hasHls && videoRef.current && camera.hlsStreamUrl) {
      if (Hls.isSupported()) {
        const hls = new Hls({ lowLatencyMode: true });
        hls.loadSource(camera.hlsStreamUrl);
        hls.attachMedia(videoRef.current);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          videoRef.current?.play().catch(() => {});
        });
        return () => hls.destroy();
      } else if (videoRef.current.canPlayType('application/vnd.apple.mpegurl')) {
        videoRef.current.src = camera.hlsStreamUrl;
        videoRef.current.play().catch(() => {});
      }
    }
  }, [hasHls, camera.hlsStreamUrl]);

  // Canvas-based realistic camera stream simulator
  useEffect(() => {
    if (hasHls) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameCount = 0;
    let lastTime = performance.now();

    const render = (time: number) => {
      frameCount++;
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      const width = canvas.width;
      const height = canvas.height;

      // Base background scene based on camera location
      ctx.save();
      
      // Clear
      ctx.fillStyle = nightVision ? '#0a0d0a' : '#141824';
      ctx.fillRect(0, 0, width, height);

      // Apply PTZ and Digital Zoom transform
      ctx.translate(width / 2, height / 2);
      const totalZoom = digitalZoom * ptzZoom;
      ctx.scale(totalZoom, totalZoom);
      ctx.translate(-width / 2 + ptzPan * 1.5, -height / 2 + ptzTilt * 1.5);

      // Draw simulated scene
      if (camera.deviceType === 'v380_4g') {
        // Rural / farm landscape
        drawRuralScene(ctx, width, height, time, nightVision);
      } else if (camera.name.toLowerCase().includes('bodega')) {
        // Warehouse / interior
        drawWarehouseScene(ctx, width, height, time, nightVision);
      } else {
        // Gate / Parking / Exterior
        drawEntranceScene(ctx, width, height, time, nightVision);
      }

      ctx.restore();

      // Digital sensor noise / scanline overlay
      drawSensorNoise(ctx, width, height, nightVision);

      // Camera OSD (On-Screen Display)
      drawOsd(ctx, width, height, camera, nightVision, metrics.fps);

      // Watermark if required
      if (showWatermark) {
        drawWatermarkOverlay(ctx, width, height, watermarkText || 'SIDESEGUATE CLIENT PORTAL');
      }

      // Schedule next frame
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [hasHls, camera, digitalZoom, nightVision, ptzPan, ptzTilt, ptzZoom, showWatermark, watermarkText, metrics.fps]);

  // Slight metric variance for realism
  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics((prev) => ({
        fps: Math.max(18, Math.min(30, (camera.fps || 25) + (Math.random() > 0.5 ? 1 : -1))),
        bitrate: Math.round((camera.bitrateKbps || 2048) + (Math.random() * 80 - 40)),
        latencyMs: Math.round(180 + Math.random() * 60)
      }));
    }, 2500);
    return () => clearInterval(timer);
  }, [camera.fps, camera.bitrateKbps]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const handleTakeSnapshot = () => {
    if (!allowSnapshot) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      const link = document.createElement('a');
      const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      link.download = `SIDESEGUATE_${camera.name.replace(/\s+/g, '_')}_${dateStr}.jpg`;
      link.href = dataUrl;
      link.click();

      setSnapshotToast('Captura guardada exitosamente');
      setTimeout(() => setSnapshotToast(null), 3000);
    } catch {
      setSnapshotToast('No se pudo guardar la captura');
      setTimeout(() => setSnapshotToast(null), 3000);
    }
  };

  const resetPtz = () => {
    setPtzPan(0);
    setPtzTilt(0);
    setPtzZoom(1);
    setDigitalZoom(1);
  };

  return (
    <div 
      ref={containerRef}
      className={`relative bg-neutral-950 rounded-xl overflow-hidden shadow-2xl border border-neutral-800 flex flex-col group ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none' : ''
      }`}
    >
      {/* Top Floating Status Bar */}
      <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between p-3 bg-gradient-to-b from-black/80 via-black/40 to-transparent pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <span className="flex h-2.5 w-2.5 relative">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${
              camera.status === 'online' ? 'bg-red-500 opacity-75' : 'bg-amber-500 opacity-75'
            }`}></span>
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
              camera.status === 'online' ? 'bg-red-600' : 'bg-amber-600'
            }`}></span>
          </span>
          <span className="text-xs font-mono font-bold tracking-wider text-red-500 bg-red-950/70 border border-red-800/60 px-2 py-0.5 rounded">
            REC • EN VIVO
          </span>
          <span className="text-xs font-semibold text-white drop-shadow truncate max-w-[200px] sm:max-w-md">
            {camera.name}
          </span>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto text-[11px] font-mono text-neutral-300">
          <span className="hidden sm:inline-block bg-black/60 px-2 py-0.5 rounded border border-neutral-700/60">
            {camera.resolution}
          </span>
          <span className="hidden md:inline-block bg-black/60 px-2 py-0.5 rounded border border-neutral-700/60 text-emerald-400">
            {metrics.fps} FPS
          </span>
          <span className="hidden lg:inline-block bg-black/60 px-2 py-0.5 rounded border border-neutral-700/60 text-sky-400">
            {metrics.bitrate} kbps
          </span>
          {nightVision && (
            <span className="bg-emerald-950/80 text-emerald-400 border border-emerald-700/60 px-1.5 py-0.5 rounded text-[10px] font-bold">
              IR NOCTURNO
            </span>
          )}
        </div>
      </div>

      {/* Main Video Viewport */}
      <div className="relative w-full aspect-video bg-neutral-950 flex items-center justify-center overflow-hidden">
        {hasHls ? (
          <video
            ref={videoRef}
            className="w-full h-full object-contain"
            muted={isMuted}
            playsInline
            autoPlay
          />
        ) : (
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            className="w-full h-full object-contain select-none"
          />
        )}

        {/* Warning Badge for V380 4G */}
        {camera.deviceType === 'v380_4g' && (
          <div className="absolute top-12 left-3 z-10 bg-amber-950/90 text-amber-200 border border-amber-600/80 px-2.5 py-1 rounded text-xs flex items-center gap-1.5 shadow-lg max-w-[90%]">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Módem 4G LTE: CGNAT detectado • Modo relay activo</span>
          </div>
        )}

        {/* Snapshot Notification Toast */}
        {snapshotToast && (
          <div className="absolute top-14 right-4 z-30 bg-emerald-600 text-white text-xs font-medium px-3 py-1.5 rounded-lg shadow-xl animate-fade-in flex items-center gap-1.5">
            <CameraIcon className="w-4 h-4" />
            {snapshotToast}
          </div>
        )}

        {/* PTZ Joystick Overlay (if toggled) */}
        {showPtzControls && allowPtz && (
          <div className="absolute bottom-14 right-4 z-20 bg-neutral-900/90 backdrop-blur-md border border-neutral-700 p-3 rounded-xl shadow-2xl text-white">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-neutral-800 text-xs font-semibold text-neutral-300">
              <span className="flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-blue-400" />
                Control PTZ ONVIF
              </span>
              <button 
                onClick={resetPtz}
                className="text-[10px] text-blue-400 hover:text-blue-300 underline"
              >
                Resetear
              </button>
            </div>

            {/* D-Pad */}
            <div className="grid grid-cols-3 gap-1 w-28 h-28 mx-auto my-1">
              <div></div>
              <button
                aria-label="Inclinar cámara arriba"
                onClick={() => setPtzTilt((t) => Math.max(-50, t - 15))}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-blue-600 rounded flex items-center justify-center text-sm font-bold transition"
              >
                ▲
              </button>
              <div></div>
              <button
                aria-label="Girar cámara a la izquierda"
                onClick={() => setPtzPan((p) => Math.max(-100, p - 20))}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-blue-600 rounded flex items-center justify-center text-sm font-bold transition"
              >
                ◀
              </button>
              <button
                aria-label="Centrar control PTZ"
                onClick={resetPtz}
                className="bg-neutral-700 hover:bg-neutral-600 rounded text-[10px] font-mono text-neutral-400"
              >
                •
              </button>
              <button
                aria-label="Girar cámara a la derecha"
                onClick={() => setPtzPan((p) => Math.min(100, p + 20))}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-blue-600 rounded flex items-center justify-center text-sm font-bold transition"
              >
                ▶
              </button>
              <div></div>
              <button
                aria-label="Inclinar cámara abajo"
                onClick={() => setPtzTilt((t) => Math.min(50, t + 15))}
                className="bg-neutral-800 hover:bg-neutral-700 active:bg-blue-600 rounded flex items-center justify-center text-sm font-bold transition"
              >
                ▼
              </button>
              <div></div>
            </div>

            {/* Optical Zoom Buttons */}
            <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-neutral-800">
              <span className="text-[10px] text-neutral-400">Zoom Óptico:</span>
              <div className="flex items-center gap-1">
                <button
                  aria-label="Reducir zoom óptico"
                  onClick={() => setPtzZoom((z) => Math.max(1, +(z - 0.25).toFixed(2)))}
                  className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-xs rounded"
                >
                  -
                </button>
                <span className="text-xs font-mono w-8 text-center">{ptzZoom}x</span>
                <button
                  aria-label="Aumentar zoom óptico"
                  onClick={() => setPtzZoom((z) => Math.min(4, +(z + 0.25).toFixed(2)))}
                  className="px-2 py-0.5 bg-neutral-800 hover:bg-neutral-700 text-xs rounded"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Floating Control Bar */}
      <div className="relative z-20 bg-neutral-900/95 border-t border-neutral-800 px-3 py-2 flex items-center justify-between text-neutral-300">
        <div className="flex items-center gap-2">
          {/* Audio toggle */}
          {allowAudio && (
            <button
              aria-label={isMuted ? 'Activar audio ambiental' : 'Silenciar audio'}
              onClick={() => setIsMuted(!isMuted)}
              className={`p-1.5 rounded-lg border text-xs transition flex items-center gap-1 ${
                isMuted 
                  ? 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white' 
                  : 'bg-emerald-950 border-emerald-600 text-emerald-300'
              }`}
              title={isMuted ? 'Silenciado' : 'Audio ambiental activo'}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span className="hidden sm:inline text-[11px] font-medium">
                {isMuted ? 'Silencio' : 'Audio ON'}
              </span>
            </button>
          )}

          {/* Night Vision IR Toggle */}
          <button
            aria-label={nightVision ? 'Desactivar visión nocturna' : 'Activar visión nocturna IR'}
            onClick={() => setNightVision(!nightVision)}
            className={`p-1.5 rounded-lg border text-xs transition flex items-center gap-1 ${
              nightVision
                ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white'
            }`}
            title="Alternar filtro infrarrojo / visión nocturna"
          >
            {nightVision ? <Moon className="w-4 h-4 text-emerald-400" /> : <Sun className="w-4 h-4" />}
            <span className="hidden sm:inline text-[11px] font-medium">
              {nightVision ? 'IR Noche' : 'Día Color'}
            </span>
          </button>

          {/* PTZ Trigger if supported */}
          {allowPtz && camera.ptzSupported && (
            <button
              aria-label="Abrir controles PTZ"
              onClick={() => setShowPtzControls(!showPtzControls)}
              className={`p-1.5 rounded-lg border text-xs transition flex items-center gap-1 ${
                showPtzControls
                  ? 'bg-blue-950 border-blue-600 text-blue-300'
                  : 'bg-neutral-800/80 border-neutral-700 text-neutral-400 hover:text-white'
              }`}
            >
              <Compass className="w-4 h-4" />
              <span className="hidden sm:inline text-[11px] font-medium">Controles PTZ</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {/* Digital Zoom */}
          <div className="flex items-center bg-neutral-800/90 rounded-lg border border-neutral-700 px-1 py-0.5">
            <button
              aria-label="Alejar zoom digital"
              disabled={digitalZoom <= 1}
              onClick={() => setDigitalZoom((z) => Math.max(1, +(z - 0.5).toFixed(1)))}
              className="p-1 hover:text-white disabled:opacity-30 transition"
              title="Alejar"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono px-1.5 text-neutral-200">
              {digitalZoom}x
            </span>
            <button
              aria-label="Acercar zoom digital"
              disabled={digitalZoom >= 3}
              onClick={() => setDigitalZoom((z) => Math.min(3, +(z + 0.5).toFixed(1)))}
              className="p-1 hover:text-white disabled:opacity-30 transition"
              title="Acercar"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Snapshot Button */}
          {allowSnapshot && (
            <button
              aria-label="Tomar captura de pantalla de la cámara"
              onClick={handleTakeSnapshot}
              className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 hover:text-white rounded-lg transition"
              title="Guardar Foto Instantánea"
            >
              <CameraIcon className="w-4 h-4" />
            </button>
          )}

          {/* Fullscreen Button */}
          <button
            aria-label={isFullscreen ? 'Salir de pantalla completa' : 'Ver en pantalla completa'}
            onClick={toggleFullscreen}
            className="p-1.5 bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 hover:text-white rounded-lg transition"
            title={isFullscreen ? 'Salir de pantalla completa' : 'Pantalla Completa'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};

// =====================================================================
// CANVAS SCENE RENDERERS (Produces ultra-realistic CCTV video feeds)
// =====================================================================

function drawEntranceScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  isNight: boolean
) {
  // Road / Ground
  const roadY = h * 0.55;
  ctx.fillStyle = isNight ? '#16191f' : '#333842';
  ctx.fillRect(0, roadY, w, h - roadY);

  // Road lines
  ctx.strokeStyle = isNight ? '#556055' : '#f0c040';
  ctx.lineWidth = 4;
  ctx.setLineDash([20, 20]);
  ctx.beginPath();
  ctx.moveTo(w * 0.1, h * 0.85);
  ctx.lineTo(w * 0.9, h * 0.85);
  ctx.stroke();
  ctx.setLineDash([]);

  // Guardhouse / Garita building
  ctx.fillStyle = isNight ? '#252a33' : '#717c8d';
  ctx.fillRect(w * 0.05, h * 0.25, w * 0.28, h * 0.4);
  // Garita roof overhang
  ctx.fillStyle = isNight ? '#1a1d24' : '#454f5d';
  ctx.fillRect(w * 0.03, h * 0.22, w * 0.32, h * 0.06);

  // Garita illuminated window
  ctx.fillStyle = isNight ? '#98b068' : '#e0f2fe';
  ctx.fillRect(w * 0.12, h * 0.33, w * 0.14, h * 0.16);

  // Security gate boom barrier (opens occasionally)
  const barrierCycle = (time / 8000) % 2;
  const barrierAngle = barrierCycle > 1.3 ? -0.8 : 0;
  ctx.save();
  ctx.translate(w * 0.35, roadY);
  ctx.rotate(barrierAngle);
  // Red/white stripes on boom
  ctx.fillStyle = '#dc2626';
  ctx.fillRect(0, -6, w * 0.3, 10);
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 6; i++) {
    ctx.fillRect(i * 35 + 15, -6, 18, 10);
  }
  ctx.restore();

  // Moving car simulation
  const carOffset = ((time / 20) % (w + 400)) - 200;
  if (carOffset > -150 && carOffset < w + 100) {
    drawCar(ctx, carOffset, roadY + 40, isNight);
  }

  // Street lamp with realistic light cone
  drawStreetLamp(ctx, w * 0.75, h * 0.15, h * 0.45, isNight);
}

function drawWarehouseScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  isNight: boolean
) {
  // Warehouse Floor (polished concrete)
  const floorY = h * 0.45;
  ctx.fillStyle = isNight ? '#1a221a' : '#424a54';
  ctx.fillRect(0, floorY, w, h - floorY);

  // High metal racks (left & right)
  drawRacks(ctx, w * 0.05, h * 0.1, w * 0.25, h * 0.65, isNight, '#ea580c');
  drawRacks(ctx, w * 0.7, h * 0.1, w * 0.25, h * 0.65, isNight, '#0284c7');

  // Forklift moving slowly in aisle
  const flPos = Math.sin(time / 2000) * (w * 0.12) + w * 0.45;
  drawForklift(ctx, flPos, floorY + 80, isNight);

  // Ceiling high-bay industrial lights
  for (let i = 0; i < 4; i++) {
    const lx = w * (0.2 + i * 0.2);
    ctx.fillStyle = isNight ? '#7a966a' : '#fef08a';
    ctx.beginPath();
    ctx.arc(lx, h * 0.08, 6, 0, Math.PI * 2);
    ctx.fill();

    // Subtle light beam
    if (!isNight) {
      const grad = ctx.createRadialGradient(lx, h * 0.08, 5, lx, h * 0.35, 120);
      grad.addColorStop(0, 'rgba(254, 240, 138, 0.2)');
      grad.addColorStop(1, 'rgba(254, 240, 138, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.moveTo(lx, h * 0.08);
      ctx.lineTo(lx - 80, h * 0.5);
      ctx.lineTo(lx + 80, h * 0.5);
      ctx.closePath();
      ctx.fill();
    }
  }
}

function drawRuralScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  time: number,
  isNight: boolean
) {
  // Horizon & Hills
  ctx.fillStyle = isNight ? '#101710' : '#223824';
  ctx.beginPath();
  ctx.moveTo(0, h * 0.4);
  ctx.bezierCurveTo(w * 0.3, h * 0.3, w * 0.6, h * 0.48, w, h * 0.35);
  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fill();

  // Perimeter Wire Fence
  ctx.strokeStyle = isNight ? '#405040' : '#889988';
  ctx.lineWidth = 1.5;
  for (let x = 0; x < w; x += 40) {
    // Post
    ctx.fillStyle = isNight ? '#253525' : '#4a5d4a';
    ctx.fillRect(x, h * 0.42, 6, h * 0.35);
  }
  // Horizontal barb wires
  for (let wy = h * 0.45; wy < h * 0.75; wy += 25) {
    ctx.beginPath();
    ctx.moveTo(0, wy);
    ctx.lineTo(w, wy);
    ctx.stroke();
  }

  // Wind-swaying tree in foreground
  const windSway = Math.sin(time / 800) * 8;
  ctx.fillStyle = isNight ? '#182418' : '#14532d';
  ctx.beginPath();
  ctx.arc(w * 0.15 + windSway, h * 0.38, 70, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = isNight ? '#0f180f' : '#3e2723';
  ctx.fillRect(w * 0.15 - 8, h * 0.42, 16, h * 0.3);
}

function drawCar(ctx: CanvasRenderingContext2D, x: number, y: number, isNight: boolean) {
  ctx.save();
  ctx.translate(x, y);

  // Car Body
  ctx.fillStyle = isNight ? '#3a4a3a' : '#1e3a8a';
  ctx.fillRect(0, -25, 110, 25);
  // Cabin
  ctx.fillRect(25, -45, 60, 22);

  // Headlights
  if (isNight) {
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(108, -18, 4, 8);
    // Headlight cone
    const grad = ctx.createLinearGradient(112, -14, 260, -14);
    grad.addColorStop(0, 'rgba(254, 240, 138, 0.6)');
    grad.addColorStop(1, 'rgba(254, 240, 138, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(112, -14);
    ctx.lineTo(260, -45);
    ctx.lineTo(260, 20);
    ctx.closePath();
    ctx.fill();
  }

  // Wheels
  ctx.fillStyle = '#111';
  ctx.beginPath();
  ctx.arc(25, 0, 12, 0, Math.PI * 2);
  ctx.arc(85, 0, 12, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawStreetLamp(
  ctx: CanvasRenderingContext2D,
  x: number,
  topY: number,
  bottomY: number,
  isNight: boolean
) {
  // Pole
  ctx.strokeStyle = isNight ? '#3a4a3a' : '#4b5563';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(x, bottomY);
  ctx.lineTo(x, topY);
  ctx.lineTo(x - 25, topY);
  ctx.stroke();

  // Lamp head
  ctx.fillStyle = isNight ? '#88a077' : '#fbbf24';
  ctx.beginPath();
  ctx.arc(x - 25, topY + 4, 6, 0, Math.PI * 2);
  ctx.fill();

  // Glow if night
  if (isNight) {
    const grad = ctx.createRadialGradient(x - 25, topY + 4, 5, x - 25, bottomY, 160);
    grad.addColorStop(0, 'rgba(180, 220, 160, 0.45)');
    grad.addColorStop(1, 'rgba(180, 220, 160, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(x - 25, topY + 4);
    ctx.lineTo(x - 120, bottomY);
    ctx.lineTo(x + 70, bottomY);
    ctx.closePath();
    ctx.fill();
  }
}

function drawRacks(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  isNight: boolean,
  color: string
) {
  ctx.strokeStyle = isNight ? '#2a3a2a' : color;
  ctx.lineWidth = 3;
  // Frame
  ctx.strokeRect(x, y, w, h);
  // Shelves
  const levels = 4;
  for (let i = 1; i < levels; i++) {
    const ly = y + (h / levels) * i;
    ctx.beginPath();
    ctx.moveTo(x, ly);
    ctx.lineTo(x + w, ly);
    ctx.stroke();

    // Pallets / cargo boxes
    ctx.fillStyle = isNight ? '#203020' : '#854d0e';
    ctx.fillRect(x + 10, ly - 28, w * 0.38, 25);
    ctx.fillStyle = isNight ? '#283828' : '#ca8a04';
    ctx.fillRect(x + w * 0.5, ly - 32, w * 0.42, 29);
  }
}

function drawForklift(ctx: CanvasRenderingContext2D, x: number, y: number, isNight: boolean) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = isNight ? '#4a5530' : '#eab308';
  ctx.fillRect(-20, -25, 45, 25);
  // Cage
  ctx.strokeStyle = '#222';
  ctx.lineWidth = 2;
  ctx.strokeRect(-10, -45, 25, 22);
  // Mast / forks
  ctx.fillStyle = '#333';
  ctx.fillRect(25, -50, 4, 50);
  ctx.fillRect(25, -5, 20, 4);
  // Wheels
  ctx.fillStyle = '#111';
  ctx.beginPath();
  ctx.arc(-10, 0, 8, 0, Math.PI * 2);
  ctx.arc(15, 0, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSensorNoise(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  isNight: boolean
) {
  // Scanlines
  ctx.fillStyle = isNight ? 'rgba(0, 30, 0, 0.08)' : 'rgba(0, 0, 0, 0.05)';
  for (let y = 0; y < h; y += 4) {
    ctx.fillRect(0, y, w, 1);
  }

  // Random pixel grain in dark scenes
  if (isNight) {
    ctx.fillStyle = 'rgba(120, 180, 120, 0.06)';
    for (let i = 0; i < 40; i++) {
      const rx = Math.random() * w;
      const ry = Math.random() * h;
      ctx.fillRect(rx, ry, 2, 2);
    }
  }
}

function drawOsd(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  camera: Camera,
  isNight: boolean,
  fps: number
) {
  ctx.save();
  ctx.font = 'bold 13px "Courier New", Courier, monospace';
  ctx.fillStyle = isNight ? '#98d898' : '#ffffff';
  ctx.shadowColor = '#000000';
  ctx.shadowBlur = 4;
  ctx.shadowOffsetX = 1;
  ctx.shadowOffsetY = 1;

  // Format real-time timestamp
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  const timeString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds} CST`;

  // Draw Camera Sub-location info at y=56 (below the top HTML bar)
  ctx.fillText(`CAM: CH${camera.channel} [${camera.deviceType.toUpperCase()}] • ${camera.codec}`, 16, 56);

  // Bottom Right: Live ticking timestamp
  const textWidth = ctx.measureText(timeString).width;
  ctx.fillText(timeString, w - textWidth - 16, h - 20);

  // Bottom Left: Security stream tag
  ctx.fillText(`SIDESEGUATE GATEWAY • LIVE ENCRYPTED`, 16, h - 20);

  ctx.restore();
}

function drawWatermarkOverlay(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  text: string
) {
  ctx.save();
  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
  ctx.textAlign = 'center';

  // Semi-transparent diagonal watermarks across frame
  ctx.translate(w / 2, h / 2);
  ctx.rotate(-Math.PI / 8);
  ctx.fillText(`SIDESEGUATE SEGURIDAD • ${text.toUpperCase()} • ENLACE PRIVADO`, 0, -60);
  ctx.fillText(`USO EXCLUSIVO AUTORIZADO • NO COPIAR NI REDISTRIBUIR`, 0, 60);

  ctx.restore();
}

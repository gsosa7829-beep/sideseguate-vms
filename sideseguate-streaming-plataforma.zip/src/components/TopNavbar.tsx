import React from 'react';
import { NavigationTab } from '../lib/types';
import { 
  Plus, 
  Search, 
  Smartphone, 
  Download, 
  ShieldCheck, 
  Radio, 
  Server, 
  Activity,
  Layers,
  Link2
} from 'lucide-react';

interface TopNavbarProps {
  currentTab: NavigationTab;
  onOpenNewLink: () => void;
  onOpenNewCamera: () => void;
  onOpenMobilePreview: () => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  camerasOnline: number;
  totalCameras: number;
  totalLinks: number;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  currentTab,
  onOpenNewLink,
  onOpenNewCamera,
  onOpenMobilePreview,
  searchTerm,
  onSearchChange,
  camerasOnline,
  totalCameras,
  totalLinks,
}) => {
  const getTabTitle = (tab: NavigationTab) => {
    switch (tab) {
      case 'videowall':
        return { section: 'MONITOREO', title: 'Muro de Video (Matriz Multicámara)' };
      case 'single_camera':
        return { section: 'MONITOREO', title: 'Inspección & Control PTZ' };
      case 'patrol':
        return { section: 'MONITOREO', title: 'Carrusel de Patrullaje Continuo' };
      case 'share_links':
        return { section: 'CLIENTES', title: 'Gestor de Enlaces Web Temporales' };
      case 'clients_projects':
        return { section: 'CLIENTES', title: 'Directorio de Clientes & Proyectos' };
      case 'access_audit':
        return { section: 'CLIENTES', title: 'Auditoría & Registro de Conexiones' };
      case 'devices_catalog':
        return { section: 'EQUIPOS & RED', title: 'Inventario de Cámaras & DVRs' };
      case 'sadp_scanner':
        return { section: 'EQUIPOS & RED', title: 'Escáner SADP Tool (Red Local)' };
      case 'windows_server':
        return { section: 'SERVIDOR WINDOWS', title: 'Gateway MediaMTX para Windows' };
      case 'zero_storage':
        return { section: 'SERVIDOR WINDOWS', title: 'Arquitectura Cero Nube (Bajo Demanda)' };
      case 'mediamtx_config':
        return { section: 'SERVIDOR WINDOWS', title: 'Configurador mediamtx.yml' };
      default:
        return { section: 'VMS', title: 'Consola de Operaciones' };
    }
  };

  const { section, title } = getTabTitle(currentTab);

  return (
    <header className="h-14 bg-neutral-900/80 border-b border-neutral-850 px-4 flex items-center justify-between gap-4 sticky top-0 z-20 backdrop-blur-md">
      {/* Breadcrumbs & Title */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="hidden sm:flex flex-col">
          <span className="text-[10px] font-mono font-semibold text-neutral-500 uppercase tracking-wider">
            {section}
          </span>
          <h2 className="text-xs font-bold text-white tracking-tight truncate max-w-xs md:max-w-md">
            {title}
          </h2>
        </div>
      </div>

      {/* Global Quick Search */}
      <div className="hidden md:flex items-center gap-2 flex-1 max-w-xs bg-neutral-950/80 px-2.5 py-1.5 rounded-lg border border-neutral-850 text-xs">
        <Search className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Buscar cámara, cliente, IP o link..."
          className="bg-transparent border-none text-xs text-white placeholder-neutral-500 focus:outline-none w-full"
        />
      </div>

      {/* Live System KPIs */}
      <div className="hidden lg:flex items-center gap-4 text-xs font-mono text-neutral-400">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>{camerasOnline}/{totalCameras} En Vivo</span>
        </div>
        <div className="text-neutral-700">|</div>
        <div>
          <span>{totalLinks} Enlaces</span>
        </div>
        <div className="text-neutral-700">|</div>
        <div className="text-emerald-400 font-bold">
          <span>0 MB Nube</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-2 shrink-0">
        <a
          href="/sideseguate-streaming-plataforma.zip"
          download="sideseguate-streaming-plataforma.zip"
          className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm"
          title="Descargar código completo y scripts para Windows (.ZIP)"
        >
          <Download className="w-3.5 h-3.5 text-sky-400" />
          <span className="hidden xl:inline">Exportar ZIP</span>
        </a>

        <button
          onClick={onOpenNewLink}
          className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm"
          title="Generar Enlace Temporal para Cliente"
        >
          <Link2 className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden sm:inline">Nuevo Enlace</span>
        </button>

        <button
          onClick={onOpenNewCamera}
          className="px-2.5 py-1.5 bg-neutral-800 hover:bg-neutral-750 text-neutral-200 border border-neutral-700/80 rounded-lg text-xs font-medium flex items-center gap-1.5 transition shadow-sm"
          title="Agregar Cámara o DVR Hikvision"
        >
          <Plus className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Añadir Cámara</span>
        </button>

        <button
          onClick={onOpenMobilePreview}
          className="px-3 py-1.5 bg-white hover:bg-neutral-100 text-neutral-950 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition shadow-sm"
          title="Simulador de Vista Móvil para el Cliente"
        >
          <Smartphone className="w-3.5 h-3.5 text-neutral-800" />
          <span>Vista Móvil</span>
        </button>
      </div>
    </header>
  );
};

import React from 'react';
import { NavigationTab } from '../lib/types';
import { 
  LayoutGrid, 
  Eye, 
  RotateCw, 
  Link2, 
  Users, 
  History, 
  Cctv, 
  SearchCode, 
  Server, 
  CloudOff, 
  FileCode, 
  Smartphone, 
  Download, 
  ChevronLeft, 
  ChevronRight,
  ShieldCheck,
  Radio,
  Activity
} from 'lucide-react';

interface SidebarProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  camerasCount: number;
  onlineCount: number;
  shareLinksCount: number;
  projectsCount: number;
  onOpenMobilePreview: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isCollapsed,
  onToggleCollapse,
  camerasCount,
  onlineCount,
  shareLinksCount,
  projectsCount,
  onOpenMobilePreview
}) => {
  const menuGroups = [
    {
      label: 'MONITOREO & VMS',
      items: [
        {
          id: 'videowall' as NavigationTab,
          label: 'Muro de Video (Matrix)',
          icon: LayoutGrid,
          badge: `${onlineCount}/${camerasCount}`,
          badgeColor: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80',
        },
        {
          id: 'single_camera' as NavigationTab,
          label: 'Cámara en Detalle',
          icon: Eye,
        },
        {
          id: 'patrol' as NavigationTab,
          label: 'Patrullaje Automático',
          icon: RotateCw,
          badge: 'Auto',
          badgeColor: 'text-sky-400 bg-sky-950/60 border-sky-800/80',
        },
      ],
    },
    {
      label: 'GESTIÓN DE CLIENTES',
      items: [
        {
          id: 'share_links' as NavigationTab,
          label: 'Enlaces Web Temporales',
          icon: Link2,
          badge: `${shareLinksCount}`,
          badgeColor: 'text-neutral-300 bg-neutral-800 border-neutral-700',
        },
        {
          id: 'clients_projects' as NavigationTab,
          label: 'Clientes & Ubicaciones',
          icon: Users,
          badge: `${projectsCount}`,
          badgeColor: 'text-neutral-300 bg-neutral-800 border-neutral-700',
        },
        {
          id: 'access_audit' as NavigationTab,
          label: 'Auditoría de Accesos',
          icon: History,
        },
      ],
    },
    {
      label: 'EQUIPOS & RED',
      items: [
        {
          id: 'devices_catalog' as NavigationTab,
          label: 'Catálogo de Cámaras & DVR',
          icon: Cctv,
        },
        {
          id: 'sadp_scanner' as NavigationTab,
          label: 'Escáner SADP Tool (LAN)',
          icon: SearchCode,
          badge: '192.168.1.41',
          badgeColor: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80',
        },
      ],
    },
    {
      label: 'SERVIDOR WINDOWS',
      items: [
        {
          id: 'windows_server' as NavigationTab,
          label: 'Gateway Windows 24/7',
          icon: Server,
          badge: '.BAT',
          badgeColor: 'text-blue-400 bg-blue-950/60 border-blue-800/80',
        },
        {
          id: 'zero_storage' as NavigationTab,
          label: 'Cero Almacenamiento Nube',
          icon: CloudOff,
          badge: '0 MB',
          badgeColor: 'text-emerald-400 bg-emerald-950/60 border-emerald-800/80',
        },
        {
          id: 'mediamtx_config' as NavigationTab,
          label: 'Configuración mediamtx.yml',
          icon: FileCode,
        },
      ],
    },
  ];

  return (
    <aside
      className={`bg-neutral-950 border-r border-neutral-850 flex flex-col justify-between transition-all duration-300 z-30 select-none ${
        isCollapsed ? 'w-16' : 'w-64'
      } shrink-0`}
    >
      {/* Top Brand Header */}
      <div>
        <div className="h-14 border-b border-neutral-850 px-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-neutral-850 border border-neutral-750 flex items-center justify-center font-mono font-bold text-white text-xs tracking-wider shrink-0 shadow-sm">
              SDG
            </div>
            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-white tracking-tight truncate">
                    SIDESEGUATE
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-neutral-400 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="truncate">Windows Gateway</span>
                </div>
              </div>
            )}
          </div>

          <button
            aria-label={isCollapsed ? 'Expandir barra lateral' : 'Colapsar barra lateral'}
            onClick={onToggleCollapse}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 border border-transparent hover:border-neutral-800 transition"
            title={isCollapsed ? 'Expandir Menú' : 'Colapsar Menú'}
          >
            {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Scrollable Navigation Groups */}
        <div className="p-2 space-y-5 overflow-y-auto max-h-[calc(100vh-14rem)] scrollbar-none">
          {menuGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-1">
              {!isCollapsed && (
                <div className="px-2.5 text-[10px] font-semibold text-neutral-500 tracking-wider uppercase font-mono mb-1.5">
                  {group.label}
                </div>
              )}

              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition ${
                      isActive
                        ? 'bg-neutral-850 text-white shadow-sm border border-neutral-700/80 font-semibold'
                        : 'text-neutral-400 hover:text-white hover:bg-neutral-900/80'
                    }`}
                    title={isCollapsed ? item.label : undefined}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-400' : 'text-neutral-500'}`} />
                    {!isCollapsed && (
                      <div className="flex items-center justify-between w-full min-w-0">
                        <span className="truncate">{item.label}</span>
                        {item.badge && (
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-mono border ${
                              item.badgeColor || 'text-neutral-400 bg-neutral-900 border-neutral-800'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Actions & Server Status Card */}
      <div className="p-2 border-t border-neutral-850 space-y-2">
        {/* Quick action buttons */}
        {!isCollapsed ? (
          <div className="space-y-1.5">
            <button
              onClick={onOpenMobilePreview}
              className="w-full py-1.5 px-2.5 bg-neutral-900 hover:bg-neutral-850 text-neutral-200 border border-neutral-800 rounded-lg text-xs font-medium flex items-center justify-between transition"
            >
              <span className="flex items-center gap-2">
                <Smartphone className="w-3.5 h-3.5 text-neutral-400" />
                <span>Simulador Móvil</span>
              </span>
              <span className="text-[10px] text-neutral-500 font-mono">Vista</span>
            </button>

            <a
              href="/sideseguate-streaming-plataforma.zip"
              download="sideseguate-streaming-plataforma.zip"
              className="w-full py-1.5 px-2.5 bg-neutral-900 hover:bg-neutral-850 text-neutral-200 border border-neutral-800 rounded-lg text-xs font-medium flex items-center justify-between transition"
            >
              <span className="flex items-center gap-2">
                <Download className="w-3.5 h-3.5 text-blue-400" />
                <span>Descargar ZIP</span>
              </span>
              <span className="text-[10px] text-blue-400 font-mono">.bat</span>
            </a>

            {/* Micro Server Summary */}
            <div className="bg-neutral-950 p-2 rounded-lg border border-neutral-850 text-[10px] space-y-1">
              <div className="flex items-center justify-between text-neutral-400 font-mono">
                <span>ESTADO</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  24/7 ACTIVO
                </span>
              </div>
              <div className="flex items-center justify-between text-neutral-500 font-mono">
                <span>NUBE</span>
                <span className="text-neutral-300">0 MB (Sin costo)</span>
              </div>
              <div className="flex items-center justify-between text-neutral-500 font-mono">
                <span>SISTEMA</span>
                <span className="text-neutral-300">Windows Nativo</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 py-1">
            <button
              onClick={onOpenMobilePreview}
              className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-850 text-neutral-300 border border-neutral-800"
              title="Simulador de Vista Móvil"
            >
              <Smartphone className="w-4 h-4 text-neutral-400" />
            </button>
            <a
              href="/sideseguate-streaming-plataforma.zip"
              download="sideseguate-streaming-plataforma.zip"
              className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-850 text-blue-400 border border-neutral-800"
              title="Descargar ZIP"
            >
              <Download className="w-4 h-4" />
            </a>
          </div>
        )}
      </div>
    </aside>
  );
};

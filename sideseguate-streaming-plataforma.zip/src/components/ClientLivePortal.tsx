import React, { useState, useEffect } from 'react';
import { Camera, ShareLink, Project } from '../lib/types';
import { verifyShareLink, formatExpirationText } from '../lib/tokenSecurity';
import { LiveCameraPlayer } from './LiveCameraPlayer';
import { 
  ShieldCheck, 
  Lock, 
  AlertCircle, 
  PhoneCall, 
  Grid2X2, 
  Square, 
  CheckCircle2, 
  Wifi, 
  Smartphone, 
  ArrowLeft,
  KeyRound,
  ExternalLink,
  Info
} from 'lucide-react';

interface ClientLivePortalProps {
  shareLink: ShareLink | null | undefined;
  cameras: Camera[];
  project?: Project;
  onBackToAdmin?: () => void;
  isAdminPreview?: boolean;
}

export const ClientLivePortal: React.FC<ClientLivePortalProps> = ({
  shareLink,
  cameras,
  project,
  onBackToAdmin,
  isAdminPreview = false,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [pinVerified, setPinVerified] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);

  // Filter cameras assigned to this share link (if empty, show all for project)
  const allowedCameras = cameras.filter((cam) => {
    if (!shareLink) return false;
    if (shareLink.cameraIds && shareLink.cameraIds.length > 0) {
      return shareLink.cameraIds.includes(cam.id);
    }
    return cam.projectId === shareLink.projectId;
  });

  const [selectedCameraId, setSelectedCameraId] = useState<string>(
    allowedCameras[0]?.id || ''
  );
  const [viewMode, setViewMode] = useState<'single' | 'grid'>('single');

  useEffect(() => {
    if (allowedCameras.length > 0 && !allowedCameras.some((c) => c.id === selectedCameraId)) {
      setSelectedCameraId(allowedCameras[0].id);
    }
  }, [allowedCameras, selectedCameraId]);

  // Check validity
  const verification = verifyShareLink(shareLink, pinVerified ? shareLink?.pinCode : undefined);

  // If requires PIN and not verified yet
  const needsPin = shareLink?.pinCode && !pinVerified && verification.reason === 'pin_required';

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shareLink?.pinCode) return;
    if (pinInput.trim() === shareLink.pinCode.trim()) {
      setPinVerified(true);
      setPinError(null);
    } else {
      setPinError('Código PIN inválido. Intente nuevamente.');
    }
  };

  // State: Link not found or invalid
  if (!shareLink) {
    return (
      <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center shadow-2xl">
          <div className="w-16 h-16 bg-red-950/80 border border-red-800/80 text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Enlace no encontrado</h2>
          <p className="text-sm text-neutral-400 mb-6">
            El enlace de transmisión de video no existe o ha sido retirado del sistema.
          </p>
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left text-xs space-y-2 mb-6">
            <div className="text-neutral-400 font-medium">Soporte Técnico SIDESEGUATE:</div>
            <div className="flex items-center gap-2 text-neutral-200">
              <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
              <span>PBX / WhatsApp: +502 5521-8840</span>
            </div>
          </div>
          {onBackToAdmin && (
            <button
              onClick={onBackToAdmin}
              className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white font-medium rounded-xl text-sm transition"
            >
              Volver al Panel de Administración
            </button>
          )}
        </div>
      </div>
    );
  }

  // State: Link Expired or Deactivated
  if (!verification.valid && !needsPin) {
    return (
      <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-2xl p-8 text-center shadow-2xl">
          <div className="w-16 h-16 bg-amber-950/80 border border-amber-800/80 text-amber-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8" />
          </div>
          <div className="inline-block px-3 py-1 bg-amber-950/60 border border-amber-800/50 rounded-full text-xs font-semibold text-amber-400 mb-3">
            {verification.reason === 'expired' ? 'ENLACE EXPIRADO' : 'ACCESO DESACTIVADO'}
          </div>
          <h2 className="text-xl font-bold text-white mb-2">{shareLink.title}</h2>
          <p className="text-sm text-neutral-400 mb-6 leading-relaxed">
            {verification.message}
          </p>

          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-left text-xs space-y-3 mb-6">
            <div className="font-semibold text-neutral-300">Detalles del Enlace:</div>
            <div className="flex justify-between text-neutral-400">
              <span>Cliente:</span>
              <span className="text-neutral-200 font-medium">{shareLink.clientName}</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Estado:</span>
              <span className="text-amber-400 font-mono">
                {shareLink.isActive ? 'Caducado por tiempo' : 'Pausado por Administrador'}
              </span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Fecha Límite:</span>
              <span className="text-neutral-300 font-mono">
                {shareLink.expiresAt ? new Date(shareLink.expiresAt).toLocaleString() : 'N/A'}
              </span>
            </div>
          </div>

          <div className="border-t border-neutral-800 pt-4 text-xs text-neutral-400 space-y-2">
            <p>Para renovar este enlace o solicitar acceso permanente:</p>
            <a
              href="tel:+50255218840"
              className="inline-flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-xl text-sm transition"
            >
              <PhoneCall className="w-4 h-4" />
              Contactar Soporte SIDESEGUATE
            </a>
          </div>

          {onBackToAdmin && (
            <button
              onClick={onBackToAdmin}
              className="mt-4 text-xs text-neutral-500 hover:text-neutral-300 transition"
            >
              ← Volver al Panel Administrador
            </button>
          )}
        </div>
      </div>
    );
  }

  // State: Needs PIN
  if (needsPin) {
    return (
      <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-2xl p-8 shadow-2xl">
          <div className="w-14 h-14 bg-blue-950/80 border border-blue-800/80 text-blue-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <KeyRound className="w-7 h-7" />
          </div>
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-white mb-1">Canal Privado Protegido</h2>
            <p className="text-xs text-neutral-400">
              {shareLink.title} • {shareLink.clientName}
            </p>
          </div>

          <form onSubmit={handleVerifyPin} className="space-y-4">
            <div>
              <label htmlFor="pin-input" className="block text-xs font-medium text-neutral-300 mb-1.5">
                Ingrese el PIN de seguridad proporcionado por SIDESEGUATE:
              </label>
              <input
                id="pin-input"
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Ej. 2026"
                autoFocus
                className="w-full text-center text-2xl tracking-[0.5em] font-mono bg-neutral-950 border border-neutral-700 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {pinError && (
              <div className="text-xs text-red-400 bg-red-950/50 border border-red-800/50 rounded-lg p-2.5 text-center">
                {pinError}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-semibold rounded-xl text-sm transition shadow-lg shadow-blue-600/20"
            >
              Desbloquear Cámaras
            </button>
          </form>

          {isAdminPreview && (
            <div className="mt-4 pt-4 border-t border-neutral-800 text-center">
              <span className="text-[11px] text-neutral-500">
                (Nota de Demo Admin: El PIN configurado es <code className="text-blue-400 font-mono">{shareLink.pinCode}</code>)
              </span>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Active Authenticated Client Portal View
  const selectedCamera = allowedCameras.find((c) => c.id === selectedCameraId) || allowedCameras[0];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col">
      {/* Top Client Header */}
      <header className="bg-neutral-900 border-b border-neutral-800 px-4 py-3 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isAdminPreview && onBackToAdmin && (
              <button
                onClick={onBackToAdmin}
                className="p-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg text-xs flex items-center gap-1 transition"
                title="Volver a consola de administración"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}

            {/* SIDESEGUATE Branding */}
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-neutral-800 border border-neutral-700 flex items-center justify-center font-mono font-bold text-white text-xs tracking-wider shadow-sm">
                SDG
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-sm font-bold text-white tracking-tight">SIDESEGUATE</h1>
                  <span className="text-neutral-600 text-xs font-mono">/</span>
                  <span className="text-xs text-neutral-400 font-medium">Portal Cliente</span>
                </div>
                <p className="text-[11px] text-neutral-400 truncate max-w-[200px] sm:max-w-md">
                  {shareLink.title}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* View Mode Switcher */}
            {allowedCameras.length > 1 && (
              <div className="flex items-center bg-neutral-950 p-0.5 rounded-lg border border-neutral-800 text-xs">
                <button
                  aria-label="Vista de una sola cámara"
                  onClick={() => setViewMode('single')}
                  className={`px-2 py-1 rounded-md transition text-xs flex items-center gap-1 font-medium ${
                    viewMode === 'single' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                  }`}
                  title="Cámara Individual"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span className="hidden md:inline text-[11px]">Individual</span>
                </button>
                <button
                  aria-label="Vista de cuadrícula de cámaras"
                  onClick={() => setViewMode('grid')}
                  className={`px-2 py-1 rounded-md transition text-xs flex items-center gap-1 font-medium ${
                    viewMode === 'grid' ? 'bg-neutral-800 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
                  }`}
                  title="Cuadrícula Múltiple"
                >
                  <Grid2X2 className="w-3.5 h-3.5" />
                  <span className="hidden md:inline text-[11px]">Mosaico</span>
                </button>
              </div>
            )}

            {/* Expiry Status */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span className="text-[11px] font-medium text-neutral-300">
                {formatExpirationText(shareLink.expiresAt)}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 flex flex-col gap-4">
        {/* Minimalist Info Banner */}
        <div className="bg-neutral-900/60 border border-neutral-800/80 rounded-xl px-3.5 py-2.5 flex items-center justify-between text-xs text-neutral-300">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-neutral-400 shrink-0" />
            <span>
              <strong>Acceso Web Directo:</strong> Video en vivo en navegador (Chrome, Safari, Edge). Sin instalar apps.
            </span>
          </div>
          <div className="hidden md:flex items-center gap-3 text-neutral-400 text-[11px]">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              HTTPS Cifrado
            </span>
            <span className="flex items-center gap-1">
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
              HLS Baja Latencia
            </span>
          </div>
        </div>

        {allowedCameras.length === 0 ? (
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-12 text-center text-neutral-400">
            <AlertCircle className="w-10 h-10 mx-auto mb-3 text-amber-500" />
            <h3 className="text-base font-semibold text-white mb-1">No hay cámaras asignadas</h3>
            <p className="text-xs">El administrador de SIDESEGUATE aún no ha asignado cámaras a este enlace.</p>
          </div>
        ) : viewMode === 'single' ? (
          /* Single Camera Focused View */
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* Big Player Area */}
            <div className="lg:col-span-3 flex flex-col gap-3">
              {selectedCamera && (
                <LiveCameraPlayer
                  camera={selectedCamera}
                  allowPtz={shareLink.allowPtz}
                  allowAudio={shareLink.allowAudio}
                  allowSnapshot={shareLink.allowSnapshot}
                  showWatermark={shareLink.showWatermark}
                  watermarkText={shareLink.clientName}
                />
              )}

              {/* Camera Metadata Card */}
              {selectedCamera && (
                <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-white text-sm">{selectedCamera.name}</span>
                      <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 font-mono text-[11px] border border-neutral-700">
                        {selectedCamera.deviceType === 'hikvision_dvr' 
                          ? 'Hikvision TurboHD DVR' 
                          : selectedCamera.deviceType === 'hikvision_ip'
                          ? 'Hikvision Cámara IP POE'
                          : selectedCamera.deviceType === 'v380_4g'
                          ? 'T-DAY 4G V380'
                          : 'Cámara RTSP'}
                      </span>
                    </div>
                    <p className="text-neutral-400">{selectedCamera.locationDesc}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-neutral-400 text-[11px]">
                    <span className="bg-neutral-950 px-2.5 py-1 rounded border border-neutral-800">
                      Resolución: <strong className="text-white font-mono">{selectedCamera.resolution}</strong>
                    </span>
                    <span className="bg-neutral-950 px-2.5 py-1 rounded border border-neutral-800">
                      FPS: <strong className="text-emerald-400 font-mono">{selectedCamera.fps}</strong>
                    </span>
                    <span className="bg-neutral-950 px-2.5 py-1 rounded border border-neutral-800">
                      Códec: <strong className="text-sky-400 font-mono">{selectedCamera.codec}</strong>
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Camera Switcher Sidebar */}
            <div className="lg:col-span-1 flex flex-col gap-2">
              <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider px-1">
                Cámaras Disponibles ({allowedCameras.length})
              </h3>
              <div className="space-y-2">
                {allowedCameras.map((cam) => {
                  const isSelected = cam.id === selectedCameraId;
                  return (
                    <button
                      key={cam.id}
                      onClick={() => setSelectedCameraId(cam.id)}
                      className={`w-full text-left p-3 rounded-xl border transition flex flex-col gap-1.5 ${
                        isSelected
                          ? 'bg-blue-950/50 border-blue-600 text-white ring-1 ring-blue-600'
                          : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-850 hover:border-neutral-700'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="font-semibold text-xs truncate max-w-[180px]">
                          {cam.name}
                        </span>
                        <span className={`w-2 h-2 rounded-full ${
                          cam.status === 'online' ? 'bg-emerald-500' : 'bg-amber-500'
                        }`} />
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-neutral-400">
                        <span className="truncate">{cam.locationDesc}</span>
                        <span className="font-mono text-[10px] text-neutral-500">CH{cam.channel}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Client Security Notice */}
              <div className="mt-4 bg-neutral-900/60 border border-neutral-800 rounded-xl p-3 text-[11px] text-neutral-400 space-y-2">
                <div className="flex items-center gap-1.5 text-neutral-200 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Transmisión Protegida
                </div>
                <p>
                  Esta transmisión es estrictamente confidencial. La plataforma SIDESEGUATE registra la IP de conexión y estampa marca de agua digital preventiva.
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Multi-Camera Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {allowedCameras.map((cam) => (
              <div key={cam.id} className="flex flex-col gap-1">
                <LiveCameraPlayer
                  camera={cam}
                  allowPtz={shareLink.allowPtz}
                  allowAudio={shareLink.allowAudio}
                  allowSnapshot={shareLink.allowSnapshot}
                  showWatermark={shareLink.showWatermark}
                  watermarkText={shareLink.clientName}
                  isCompact={true}
                />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-neutral-900 border-t border-neutral-800 px-4 py-3 text-center text-xs text-neutral-500">
        <p>
          © 2026 SIDESEGUATE • Seguridad Electrónica & Monitoreo en Vivo • Ciudad de Guatemala
        </p>
      </footer>
    </div>
  );
};
